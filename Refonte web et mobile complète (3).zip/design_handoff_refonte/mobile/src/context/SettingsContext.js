import React, { createContext, useContext, useState, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

const SettingsContext = createContext();

// ─── Palette IUCTrack v2 — charbon / crème / rouge / vert ───
// Toutes les clés existantes (bg, card, card2, text, muted, border, input, red, green)
// sont conservées : chaque écran existant se rethème automatiquement.
// Nouvelles clés : redInk, greenInk, gold, blue, panel, panelInk, panelMuted, tabbar, tabMuted.

const PALETTES = {
  dark: {
    bg:      '#1B2026',
    card:    '#232A33',
    card2:   '#2A323C',
    text:    '#EDF1F5',
    muted:   '#8B97A5',
    border:  'rgba(255,255,255,0.09)',
    input:   '#1A1F26',
    red:     '#C43A2F',
    green:   '#22A06B',
    redInk:  '#E8836F',
    greenInk:'#4CC496',
    gold:    '#E9A84C',
    blue:    '#6B8FCB',
    panel:   '#F4EEE0',
    panelInk:'#23282F',
    panelMuted: '#8A8474',
    tabbar:  '#252C35',
    tabMuted:'#7E8996',
    tabActiveBg: '#F4EEE0',
    tabActiveInk: '#23282F',
  },
  light: {
    bg:      '#F0EDE4',
    card:    '#FFFFFF',
    card2:   '#F5F2EA',
    text:    '#23282F',
    muted:   '#79828E',
    border:  'rgba(35,40,47,0.10)',
    input:   '#F1EFE7',
    red:     '#C43A2F',
    green:   '#1D8A5E',
    redInk:  '#B03427',
    greenInk:'#1D8A5E',
    gold:    '#D9942F',
    blue:    '#5C80BF',
    panel:   '#1C4534',
    panelInk:'#F0EDE4',
    panelMuted: '#93B3A3',
    tabbar:  '#1C4534',
    tabMuted:'#93B3A3',
    tabActiveBg: '#F4EEE0',
    tabActiveInk: '#23282F',
  },
};

// Méta statuts partagée (mêmes couleurs que le dashboard web v2)
export const STATUTS_META = {
  envoyee:  { color: '#6B8FCB', bg: 'rgba(107,143,203,0.16)', icon: 'send' },
  en_cours: { color: '#E9A84C', bg: 'rgba(233,168,76,0.16)',  icon: 'clock' },
  terminee: { color: '#22A06B', bg: 'rgba(34,160,107,0.16)',  icon: 'check-circle' },
};

export const SettingsProvider = ({ children }) => {
  const [theme, setTheme]   = useState('dark');
  const [langue, setLangue] = useState('fr');

  useEffect(() => { loadSettings(); }, []);

  const loadSettings = async () => {
    try {
      const t = await AsyncStorage.getItem('theme');
      const l = await AsyncStorage.getItem('langue');
      if (t) setTheme(t);
      if (l) setLangue(l);
    } catch (e) { console.error(e); }
  };

  const toggleTheme = async (t) => {
    setTheme(t);
    await AsyncStorage.setItem('theme', t);
  };

  const toggleLangue = async (l) => {
    setLangue(l);
    await AsyncStorage.setItem('langue', l);
  };

  const colors = PALETTES[theme] || PALETTES.dark;

  const t = {
    fr: {
      accueil: 'Accueil', demandes: 'Demandes',
      notifications: 'Notifications', profil: 'Profil',
      mesdemandes: 'Mes\nDemandes', vosdemandes: 'Vos\nDemandes',
      monprofil: 'Mon\nProfil', parametres: 'Paramètres',
      connexion: 'Connexion', matricule: 'Matricule étudiant',
      seconnecter: 'Se connecter →', decouvrir: "Découvrir l'IUC sans compte",
      bonjour: 'Bonjour', typesdispo: 'Types disponibles',
      actionsrapides: 'Actions rapides', nouvelledemande: 'Nouvelle\ndemande',
      mesdemandesshort: 'Mes\ndemandes', notifs: 'Notifi-\ncations',
      monprofilshort: 'Mon\nprofil', voirtout: 'Voir tout',
      documentsrequis: 'Documents requis', soumettredemande: 'Soumettre la demande',
      envoyee: 'Envoyée', encours: 'En cours', terminee: 'Terminée',
      aucunedemande: 'Aucune demande', aucunenotif: 'Aucune notification',
      theme: 'Thème', langue: 'Langue', sombre: 'Sombre', clair: 'Clair',
      francais: 'Français', anglais: 'Anglais', deconnexion: 'Se déconnecter',
      informations: 'Informations', nomcomplet: 'Nom complet',
      motdepasse: 'Mot de passe', defini: '✅ Défini', nondefini: '⚠️ Non défini',
      // ── nouvelles clés v2 ──
      suivi: 'Suivi de la demande', progression: 'Progression',
      documentsjoints: 'Documents joints', suivicours: 'Suivi en cours',
      etape1desc: 'Votre demande a été soumise avec les documents joints.',
      etape2desc: "L'administration traite votre dossier.",
      etape3desc: 'Document prêt — à récupérer à la scolarité.',
    },
    en: {
      accueil: 'Home', demandes: 'Requests',
      notifications: 'Notifications', profil: 'Profile',
      mesdemandes: 'My\nRequests', vosdemandes: 'Your\nRequests',
      monprofil: 'My\nProfile', parametres: 'Settings',
      connexion: 'Login', matricule: 'Student ID',
      seconnecter: 'Sign in →', decouvrir: 'Discover IUC without account',
      bonjour: 'Hello', typesdispo: 'Available types',
      actionsrapides: 'Quick actions', nouvelledemande: 'New\nrequest',
      mesdemandesshort: 'My\nrequests', notifs: 'Notifi-\ncations',
      monprofilshort: 'My\nprofile', voirtout: 'See all',
      documentsrequis: 'Required documents', soumettredemande: 'Submit request',
      envoyee: 'Sent', encours: 'In progress', terminee: 'Completed',
      aucunedemande: 'No requests', aucunenotif: 'No notifications',
      theme: 'Theme', langue: 'Language', sombre: 'Dark', clair: 'Light',
      francais: 'French', anglais: 'English', deconnexion: 'Sign out',
      informations: 'Information', nomcomplet: 'Full name',
      motdepasse: 'Password', defini: '✅ Set', nondefini: '⚠️ Not set',
      // ── new v2 keys ──
      suivi: 'Request tracking', progression: 'Progress',
      documentsjoints: 'Attached documents', suivicours: 'Active tracking',
      etape1desc: 'Your request was submitted with attached documents.',
      etape2desc: 'Administration is processing your file.',
      etape3desc: 'Document ready — pick up at the registrar.',
    }
  };

  return (
    <SettingsContext.Provider value={{ theme, langue, toggleTheme, toggleLangue, colors, t: t[langue] }}>
      {children}
    </SettingsContext.Provider>
  );
};

export const useSettings = () => useContext(SettingsContext);
