import React, { useState, useEffect, useRef } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Feather } from '@expo/vector-icons';
import { useAuth } from '../context/AuthContext';
import { useSettings } from '../context/SettingsContext';
import { View, ActivityIndicator, Text, StyleSheet, TouchableOpacity, AppState } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import api from '../services/api';

import LoginScreen            from '../screens/auth/LoginScreen';
import HomeScreen             from '../screens/etudiant/HomeScreen';
import NouvelleDemandeScreen  from '../screens/etudiant/NouvelleDemandeScreen';
import MesDemandesScreen      from '../screens/etudiant/MesDemandesScreen';
import DetailDemandeScreen    from '../screens/etudiant/DetailDemandeScreen';
import NotificationsScreen    from '../screens/etudiant/NotificationsScreen';
import ProfilScreen           from '../screens/etudiant/ProfilScreen';
import ParametresScreen       from '../screens/etudiant/ParametresScreen';
import DecouvrirIUCScreen     from '../screens/visiteur/DecouvrirIUCScreen';
import ChoixTypeDemandeScreen from '../screens/etudiant/ChoixTypeDemandeScreen';
import ChatScreen             from '../screens/etudiant/ChatScreen';
import MessagerieListScreen   from '../screens/etudiant/MessagerieListScreen';
import ConversationScreen     from '../screens/etudiant/ConversationScreen';

const Stack = createNativeStackNavigator();
const Tab   = createBottomTabNavigator();

// ─── Tab bar v2 : pilule flottante vert sombre, icônes seules, actif = pastille crème ───
function FloatingTabBar({ state, descriptors, navigation, nonLus }) {
  const insets = useSafeAreaInsets();
  const { colors } = useSettings();

  const ICONS = ['home', 'file-text', 'message-circle', 'bell', 'user'];

  return (
    <View pointerEvents="box-none" style={[S.wrap, { bottom: Math.max(insets.bottom, 10) + 6 }]}>
      <View style={[S.bar, { backgroundColor: colors.tabbar }]}>
        {state.routes.map((route, index) => {
          const isFocused = state.index === index;
          const onPress = () => {
            const event = navigation.emit({ type: 'tabPress', target: route.key, canPreventDefault: true });
            if (!isFocused && !event.defaultPrevented) navigation.navigate(route.name);
          };
          return (
            <TouchableOpacity
              key={route.key}
              onPress={onPress}
              activeOpacity={0.8}
              style={[S.tab, isFocused && { backgroundColor: colors.tabActiveBg }]}
            >
              <Feather
                name={ICONS[index] || 'circle'}
                size={20}
                color={isFocused ? colors.tabActiveInk : colors.tabMuted}
              />
              {/* Badge messages non lus — donnée réelle */}
              {index === 2 && nonLus > 0 && (
                <View style={S.badge}>
                  <Text style={S.badgeText}>{nonLus > 9 ? '9+' : nonLus}</Text>
                </View>
              )}
              {/* Point notifications */}
              {index === 3 && <View style={S.dot} />}
            </TouchableOpacity>
          );
        })}
      </View>
    </View>
  );
}

function TabNavigator() {
  const { etudiant } = useAuth();
  const { t } = useSettings();
  const [nonLus, setNonLus] = useState(0);
  const pollRef = useRef(null);

  useEffect(() => {
    if (!etudiant) return;
    fetchNonLus();
    pollRef.current = setInterval(fetchNonLus, 5000);
    const sub = AppState.addEventListener('change', (s) => { if (s === 'active') fetchNonLus(); });
    return () => { clearInterval(pollRef.current); sub.remove(); };
  }, [etudiant]);

  const fetchNonLus = async () => {
    try {
      const res = await api.get('/etudiant/messagerie/non-lus');
      setNonLus(res.data.total || 0);
    } catch (e) { /* silencieux */ }
  };

  return (
    <Tab.Navigator
      tabBar={(props) => <FloatingTabBar {...props} nonLus={nonLus} />}
      screenOptions={{ headerShown: false }}
    >
      <Tab.Screen name={t.accueil}       component={HomeScreen} />
      <Tab.Screen name={t.demandes}      component={MesDemandesScreen} />
      <Tab.Screen
        name="Messages"
        component={MessagerieListScreen}
        listeners={{ tabPress: () => setTimeout(fetchNonLus, 500) }}
      />
      <Tab.Screen name={t.notifications} component={NotificationsScreen} />
      <Tab.Screen name={t.profil}        component={ProfilScreen} />
    </Tab.Navigator>
  );
}

export default function AppNavigator() {
  const { etudiant, loading } = useAuth();
  const { colors } = useSettings();

  if (loading) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: colors.bg }}>
        <ActivityIndicator size="large" color="#C43A2F" />
      </View>
    );
  }

  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        {!etudiant ? (
          <>
            <Stack.Screen name="Login"        component={LoginScreen} />
            <Stack.Screen name="DecouvrirIUC" component={DecouvrirIUCScreen} />
            <Stack.Screen name="Chat"         component={ChatScreen} />
          </>
        ) : (
          <>
            <Stack.Screen name="Main"                   component={TabNavigator} />
            <Stack.Screen name="ChoixTypeDemandeScreen" component={ChoixTypeDemandeScreen} />
            <Stack.Screen name="NouvelleDemandeScreen"  component={NouvelleDemandeScreen} />
            <Stack.Screen name="DetailDemandeScreen"    component={DetailDemandeScreen} />
            <Stack.Screen name="Parametres"             component={ParametresScreen} />
            <Stack.Screen name="Chat"                   component={ChatScreen} />
            <Stack.Screen name="Conversation"           component={ConversationScreen} />
          </>
        )}
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const S = StyleSheet.create({
  wrap: { position: 'absolute', left: 20, right: 20 },
  bar: {
    height: 64,
    borderRadius: 24,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-around',
    paddingHorizontal: 10,
    shadowColor: '#000',
    shadowOpacity: 0.28,
    shadowRadius: 20,
    shadowOffset: { width: 0, height: 12 },
    elevation: 14,
  },
  tab: { width: 46, height: 46, borderRadius: 15, alignItems: 'center', justifyContent: 'center' },
  badge: {
    position: 'absolute', top: 4, right: 4,
    backgroundColor: '#C43A2F', borderRadius: 9,
    minWidth: 16, height: 16,
    alignItems: 'center', justifyContent: 'center', paddingHorizontal: 3,
  },
  badgeText: { color: '#fff', fontSize: 9, fontWeight: '800' },
  dot: { position: 'absolute', top: 6, right: 8, width: 7, height: 7, borderRadius: 4, backgroundColor: '#C43A2F' },
});
