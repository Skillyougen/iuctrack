import React, { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, ScrollView,
  TouchableOpacity, ActivityIndicator
} from 'react-native';
import { Feather } from '@expo/vector-icons';
import { useSettings } from '../../context/SettingsContext';
import api from '../../services/api';

// v2 — Étape 1/2 : barre de progression segmentée, cartes type avec
// icône rouge 46px, description et chip or « N documents requis ».

export default function ChoixTypeDemandeScreen({ navigation }) {
  const { colors, t, langue } = useSettings();
  const fr = langue === 'fr';
  const [types, setTypes] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => { fetchTypes(); }, []);

  const fetchTypes = async () => {
    try {
      const res = await api.get('/type-demandes');
      setTypes(res.data.filter(tp => tp.actif));
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  };

  return (
    <View style={[S.root, { backgroundColor: colors.bg }]}>
      {/* HEADER */}
      <View style={S.header}>
        <TouchableOpacity
          onPress={() => navigation.goBack()}
          style={[S.backBtn, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Feather name="chevron-left" size={20} color={colors.text} />
        </TouchableOpacity>
        <View style={{ flex: 1 }}>
          <Text style={[S.headerTitle, { color: colors.text }]}>
            {fr ? 'Nouvelle demande' : 'New request'}
          </Text>
          <Text style={[S.headerSub, { color: colors.muted }]}>
            {fr ? 'Étape 1 sur 2 — Choisissez le type' : 'Step 1 of 2 — Choose the type'}
          </Text>
        </View>
      </View>

      {/* PROGRESSION — 2 segments */}
      <View style={S.stepsRow}>
        <View style={[S.stepSeg, { backgroundColor: '#C43A2F' }]} />
        <View style={[S.stepSeg, { backgroundColor: colors.border }]} />
      </View>

      {loading ? (
        <View style={S.centered}>
          <ActivityIndicator size="large" color="#C43A2F" />
        </View>
      ) : (
        <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={S.scroll}>
          {types.map((type) => (
            <TouchableOpacity
              key={type.id}
              style={[S.typeCard, { backgroundColor: colors.card, borderColor: colors.border }]}
              onPress={() => navigation.navigate('NouvelleDemandeScreen', { type })}
              activeOpacity={0.8}>
              <View style={[S.typeIcon, { backgroundColor: 'rgba(196,58,47,0.12)' }]}>
                <Feather name="file-text" size={19} color={colors.redInk} />
              </View>
              <View style={{ flex: 1, minWidth: 0 }}>
                <Text style={[S.typeLibelle, { color: colors.text }]}>{type.libelle}</Text>
                {type.description ? (
                  <Text style={[S.typeDesc, { color: colors.muted }]} numberOfLines={2}>
                    {type.description}
                  </Text>
                ) : null}
                <View style={S.typeChip}>
                  <Text style={[S.typeChipText, { color: colors.gold }]}>
                    {type.documents_requis?.length || 0} {fr ? 'documents requis' : 'required documents'}
                  </Text>
                </View>
              </View>
              <Feather name="chevron-right" size={16} color={colors.muted} />
            </TouchableOpacity>
          ))}
          <View style={{ height: 40 }} />
        </ScrollView>
      )}
    </View>
  );
}

const S = StyleSheet.create({
  root: { flex: 1 },
  centered: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  header: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingHorizontal: 22, paddingTop: 56, paddingBottom: 14 },
  backBtn: { width: 38, height: 38, borderRadius: 13, alignItems: 'center', justifyContent: 'center', borderWidth: 1 },
  headerTitle: { fontSize: 20, fontWeight: '800', letterSpacing: -0.4 },
  headerSub: { fontSize: 11.5, marginTop: 1 },
  stepsRow: { flexDirection: 'row', gap: 5, paddingHorizontal: 22, marginBottom: 18 },
  stepSeg: { flex: 1, height: 4, borderRadius: 2 },
  scroll: { paddingHorizontal: 22, gap: 10 },
  typeCard: {
    borderRadius: 18, padding: 15, flexDirection: 'row',
    alignItems: 'center', gap: 13, borderWidth: 1.5,
  },
  typeIcon: { width: 46, height: 46, borderRadius: 14, alignItems: 'center', justifyContent: 'center', flexShrink: 0 },
  typeLibelle: { fontSize: 13.5, fontWeight: '700' },
  typeDesc: { fontSize: 11, lineHeight: 16, marginTop: 2 },
  typeChip: {
    alignSelf: 'flex-start', backgroundColor: 'rgba(233,168,76,0.12)',
    borderRadius: 999, paddingHorizontal: 9, paddingVertical: 3, marginTop: 5,
  },
  typeChipText: { fontSize: 10, fontWeight: '700' },
});
