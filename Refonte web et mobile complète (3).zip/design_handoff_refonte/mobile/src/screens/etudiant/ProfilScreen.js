import React, { useState, useCallback } from 'react';
import {
  View, Text, StyleSheet, ScrollView,
  TouchableOpacity, Alert, TextInput, ActivityIndicator,
  Image, Modal
} from 'react-native';
import { Feather } from '@expo/vector-icons';
import { useFocusEffect } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as ImagePicker from 'expo-image-picker';
import * as ImageManipulator from 'expo-image-manipulator';
import { useAuth } from '../../context/AuthContext';
import { useSettings } from '../../context/SettingsContext';
import api from '../../services/api';

const BASE_URL = 'http://192.168.137.1:8000/storage/';

// v2 — Profil : carte héros verte (avatar cerclé or, nom, matricule, chip filière),
// 3 cartes stats réelles, carte INFORMATIONS en lignes, mot de passe repliable (or),
// ligne Paramètres, déconnexion rouge. Logique photo/crop/password conservée.

export default function ProfilScreen({ navigation }) {
  const { etudiant, logout, setEtudiant } = useAuth();
  const { colors, t, langue } = useSettings();
  const fr = langue === 'fr';
  const [showPasswordForm, setShowPasswordForm] = useState(false);
  const [password, setPassword]               = useState('');
  const [passwordConfirm, setPasswordConfirm] = useState('');
  const [loading, setLoading]                 = useState(false);
  const [uploadingPhoto, setUploadingPhoto]   = useState(false);
  const [showCrop, setShowCrop]               = useState(false);
  const [tempPhoto, setTempPhoto]             = useState(null);
  const [stats, setStats]                     = useState({ total: 0, actives: 0, terminees: 0 });

  // Stats réelles depuis /etudiant/demandes
  useFocusEffect(useCallback(() => {
    api.get('/etudiant/demandes')
      .then(res => {
        const d = res.data;
        setStats({
          total: d.length,
          actives: d.filter(x => x.statut !== 'terminee').length,
          terminees: d.filter(x => x.statut === 'terminee').length,
        });
      })
      .catch(() => {});
  }, []));

  // ── PHOTO DE PROFIL (logique conservée) ──
  const choisirPhoto = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert(fr ? 'Permission refusée' : 'Permission denied',
        fr ? "Autorisez l'accès à la galerie dans les paramètres." : 'Allow gallery access in settings.');
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.85,
    });
    if (!result.canceled) {
      setTempPhoto(result.assets[0].uri);
      setShowCrop(true);
    }
  };

  const confirmerPhoto = async () => {
    if (!tempPhoto) return;
    setUploadingPhoto(true);
    setShowCrop(false);
    try {
      const manipulated = await ImageManipulator.manipulateAsync(
        tempPhoto,
        [{ resize: { width: 300, height: 300 } }],
        { compress: 0.85, format: ImageManipulator.SaveFormat.JPEG }
      );
      const formData = new FormData();
      formData.append('photo', { uri: manipulated.uri, name: 'photo_profil.jpg', type: 'image/jpeg' });
      const res = await api.post('/etudiant/photo', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      const updatedEtudiant = { ...etudiant, photo: res.data.photo };
      setEtudiant(updatedEtudiant);
      await AsyncStorage.setItem('etudiant', JSON.stringify(updatedEtudiant));
      setTempPhoto(null);
    } catch (e) {
      Alert.alert('Erreur', e?.response?.data?.message || 'Impossible de sauvegarder la photo.');
    } finally { setUploadingPhoto(false); }
  };

  // ── MOT DE PASSE (logique conservée) ──
  const handleSetPassword = async () => {
    if (password.length < 6) {
      Alert.alert('Erreur', fr ? 'Le mot de passe doit contenir au moins 6 caractères.' : 'Password must be at least 6 characters.');
      return;
    }
    if (password !== passwordConfirm) {
      Alert.alert('Erreur', fr ? 'Les mots de passe ne correspondent pas.' : 'Passwords do not match.');
      return;
    }
    setLoading(true);
    try {
      await api.post('/etudiant/set-password', { password, password_confirmation: passwordConfirm });
      const updatedEtudiant = { ...etudiant, has_password: true };
      setEtudiant(updatedEtudiant);
      await AsyncStorage.setItem('etudiant', JSON.stringify(updatedEtudiant));
      Alert.alert('✅', fr ? 'Mot de passe défini avec succès.' : 'Password set successfully.');
      setShowPasswordForm(false);
      setPassword(''); setPasswordConfirm('');
    } catch (e) {
      Alert.alert('Erreur', e?.response?.data?.message || 'Impossible de définir le mot de passe.');
    } finally { setLoading(false); }
  };

  const handleLogout = () => {
    Alert.alert(t.deconnexion, fr ? 'Voulez-vous vraiment vous déconnecter ?' : 'Do you really want to sign out?', [
      { text: fr ? 'Annuler' : 'Cancel', style: 'cancel' },
      { text: fr ? 'Déconnecter' : 'Sign out', style: 'destructive', onPress: logout },
    ]);
  };

  const photoUri = etudiant?.photo ? BASE_URL + etudiant.photo : null;
  const initiales = `${etudiant?.nom?.charAt(0) || ''}${etudiant?.prenom?.charAt(0) || ''}`;

  return (
    <View style={[S.root, { backgroundColor: colors.bg }]}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={S.scroll}>

        <Text style={[S.bigTitle, { color: colors.text }]}>{fr ? 'Mon profil' : 'My profile'}</Text>

        {/* CARTE HÉROS — panneau vert */}
        <View style={[S.heroCard, { backgroundColor: colors.panel }]}>
          <TouchableOpacity onPress={choisirPhoto} style={S.avatarWrap} activeOpacity={0.8}>
            {uploadingPhoto ? (
              <View style={[S.avatarCircle, { backgroundColor: '#C43A2F' }]}>
                <ActivityIndicator color="#fff" />
              </View>
            ) : photoUri ? (
              <Image source={{ uri: photoUri }} style={S.avatarCircle} />
            ) : (
              <View style={[S.avatarCircle, { backgroundColor: '#C43A2F' }]}>
                <Text style={S.avatarText}>{initiales}</Text>
              </View>
            )}
            <View style={S.cameraBadge}>
              <Feather name="camera" size={11} color="#C43A2F" />
            </View>
          </TouchableOpacity>
          <View style={{ flex: 1, minWidth: 0 }}>
            <Text style={[S.heroName, { color: colors.panelInk }]}>{etudiant?.prenom} {etudiant?.nom}</Text>
            <Text style={[S.heroMat, { color: colors.panelMuted }]}>{etudiant?.matricule}</Text>
            <View style={S.filiereChip}>
              <Text style={[S.filiereChipText, { color: colors.panelInk }]} numberOfLines={1}>
                {etudiant?.filiere}
              </Text>
            </View>
          </View>
        </View>

        {/* STATS RÉELLES */}
        <View style={S.statsRow}>
          <View style={[S.statCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Text style={[S.statVal, { color: colors.text }]}>{stats.total}</Text>
            <Text style={[S.statLabel, { color: colors.muted }]}>{fr ? 'Demandes' : 'Requests'}</Text>
          </View>
          <View style={[S.statCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Text style={[S.statVal, { color: colors.gold }]}>{stats.actives}</Text>
            <Text style={[S.statLabel, { color: colors.muted }]}>{fr ? 'Actives' : 'Active'}</Text>
          </View>
          <View style={[S.statCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Text style={[S.statVal, { color: colors.greenInk }]}>{stats.terminees}</Text>
            <Text style={[S.statLabel, { color: colors.muted }]}>{fr ? 'Terminées' : 'Done'}</Text>
          </View>
        </View>

        {/* INFORMATIONS — lignes label / valeur */}
        <View style={[S.infoCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Text style={[S.infoCardTitle, { color: colors.muted, borderBottomColor: colors.border }]}>
            {t.informations.toUpperCase()}
          </Text>
          {[
            { label: fr ? 'Nom' : 'Last name', val: etudiant?.nom },
            { label: fr ? 'Prénom' : 'First name', val: etudiant?.prenom },
            { label: 'Matricule', val: etudiant?.matricule },
            { label: fr ? 'Filière' : 'Program', val: etudiant?.filiere, green: true },
          ].map((item, i, arr) => (
            <View key={i} style={[S.infoRow, { borderBottomColor: colors.border, borderBottomWidth: i < arr.length - 1 ? 1 : 0 }]}>
              <Text style={[S.infoLabel, { color: colors.muted }]}>{item.label}</Text>
              <Text style={[S.infoVal, { color: item.green ? colors.greenInk : colors.text }]} numberOfLines={1}>
                {item.val}
              </Text>
            </View>
          ))}
        </View>

        {/* MOT DE PASSE — repliable */}
        <View style={[S.rowCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <TouchableOpacity style={S.rowHead} onPress={() => setShowPasswordForm(!showPasswordForm)} activeOpacity={0.8}>
            <View style={[S.rowIcon, { backgroundColor: 'rgba(233,168,76,0.13)' }]}>
              <Feather name="lock" size={16} color={colors.gold} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={[S.rowTitle, { color: colors.text }]}>
                {etudiant?.has_password
                  ? (fr ? 'Modifier le mot de passe' : 'Change password')
                  : (fr ? 'Définir un mot de passe' : 'Set a password')}
              </Text>
              <Text style={[S.rowSub, { color: etudiant?.has_password ? colors.greenInk : colors.gold }]}>
                {etudiant?.has_password
                  ? (fr ? 'Mot de passe défini' : 'Password set')
                  : (fr ? 'Aucun mot de passe défini' : 'No password set')}
              </Text>
            </View>
            <Feather name={showPasswordForm ? 'chevron-down' : 'chevron-right'} size={15} color={colors.muted} />
          </TouchableOpacity>
          {showPasswordForm && (
            <View style={[S.pwdForm, { borderTopColor: colors.border }]}>
              <Text style={[S.pwdHint, { color: colors.muted }]}>
                {fr
                  ? 'Sécurisez votre compte : votre matricule seul ne suffira plus pour vous connecter.'
                  : 'Secure your account: your student ID alone will no longer be enough to sign in.'}
              </Text>
              <TextInput
                style={[S.input, { backgroundColor: colors.input, color: colors.text, borderColor: colors.border }]}
                placeholder={fr ? 'Nouveau mot de passe' : 'New password'}
                placeholderTextColor={colors.muted}
                secureTextEntry value={password} onChangeText={setPassword}
              />
              <TextInput
                style={[S.input, { backgroundColor: colors.input, color: colors.text, borderColor: colors.border }]}
                placeholder={fr ? 'Confirmer le mot de passe' : 'Confirm password'}
                placeholderTextColor={colors.muted}
                secureTextEntry value={passwordConfirm} onChangeText={setPasswordConfirm}
              />
              <TouchableOpacity style={S.btnSavePwd} onPress={handleSetPassword} disabled={loading} activeOpacity={0.85}>
                {loading
                  ? <ActivityIndicator color="#23282F" size="small" />
                  : <Text style={S.btnSavePwdText}>{fr ? 'Enregistrer le mot de passe' : 'Save password'}</Text>}
              </TouchableOpacity>
            </View>
          )}
        </View>

        {/* PARAMÈTRES */}
        <TouchableOpacity
          style={[S.rowCard, S.rowHead, { backgroundColor: colors.card, borderColor: colors.border }]}
          onPress={() => navigation.navigate('Parametres')} activeOpacity={0.8}>
          <View style={[S.rowIcon, { backgroundColor: 'rgba(34,160,107,0.12)' }]}>
            <Feather name="settings" size={16} color={colors.greenInk} />
          </View>
          <Text style={[S.rowTitle, { color: colors.text, flex: 1 }]}>
            {fr ? 'Paramètres — Thème & Langue' : 'Settings — Theme & Language'}
          </Text>
          <Feather name="chevron-right" size={15} color={colors.muted} />
        </TouchableOpacity>

        {/* DÉCONNEXION */}
        <TouchableOpacity style={S.btnLogout} onPress={handleLogout} activeOpacity={0.8}>
          <Feather name="log-out" size={15} color={colors.redInk} />
          <Text style={[S.btnLogoutText, { color: colors.redInk }]}>{t.deconnexion}</Text>
        </TouchableOpacity>

        <View style={{ height: 120 }} />
      </ScrollView>

      {/* MODAL APERÇU PHOTO (logique conservée) */}
      <Modal visible={showCrop} transparent animationType="fade">
        <View style={S.cropOverlay}>
          <View style={[S.cropBox, { backgroundColor: colors.card }]}>
            <Text style={[S.cropTitle, { color: colors.text }]}>
              {fr ? 'Aperçu de la photo' : 'Photo preview'}
            </Text>
            {tempPhoto && <Image source={{ uri: tempPhoto }} style={S.cropPreview} />}
            <Text style={[S.cropHint, { color: colors.muted }]}>
              {fr ? 'La photo sera recadrée en cercle automatiquement.' : 'Photo will be automatically cropped to a circle.'}
            </Text>
            <View style={S.cropActions}>
              <TouchableOpacity
                onPress={() => { setShowCrop(false); setTempPhoto(null); }}
                style={[S.cropBtnCancel, { backgroundColor: colors.card2, borderColor: colors.border }]}>
                <Text style={[S.cropBtnCancelTxt, { color: colors.muted }]}>{fr ? 'Annuler' : 'Cancel'}</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={confirmerPhoto} style={S.cropBtnConfirm}>
                <Feather name="check" size={16} color="#fff" />
                <Text style={S.cropBtnConfirmTxt}>{fr ? 'Confirmer' : 'Confirm'}</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const S = StyleSheet.create({
  root: { flex: 1 },
  scroll: { paddingHorizontal: 22, gap: 14 },
  bigTitle: { fontSize: 26, fontWeight: '800', letterSpacing: -0.5, paddingTop: 56, marginBottom: 2 },

  heroCard: { borderRadius: 22, padding: 20, flexDirection: 'row', alignItems: 'center', gap: 15 },
  avatarWrap: { position: 'relative', flexShrink: 0 },
  avatarCircle: {
    width: 62, height: 62, borderRadius: 31, alignItems: 'center', justifyContent: 'center',
    borderWidth: 3, borderColor: '#E9A84C',
  },
  avatarText: { color: '#fff', fontSize: 19, fontWeight: '800' },
  cameraBadge: {
    position: 'absolute', bottom: -2, right: -2, width: 24, height: 24, borderRadius: 12,
    backgroundColor: '#F4EEE0', alignItems: 'center', justifyContent: 'center',
  },
  heroName: { fontSize: 18, fontWeight: '800' },
  heroMat: { fontSize: 11.5, marginTop: 1 },
  filiereChip: {
    alignSelf: 'flex-start', backgroundColor: 'rgba(0,0,0,0.18)',
    borderRadius: 999, paddingHorizontal: 10, paddingVertical: 3, marginTop: 6, maxWidth: '100%',
  },
  filiereChipText: { fontSize: 10, fontWeight: '800' },

  statsRow: { flexDirection: 'row', gap: 9 },
  statCard: { flex: 1, borderRadius: 16, borderWidth: 1, padding: 13, alignItems: 'center' },
  statVal: { fontSize: 22, fontWeight: '800' },
  statLabel: { fontSize: 10, fontWeight: '600', marginTop: 2 },

  infoCard: { borderRadius: 20, borderWidth: 1, overflow: 'hidden' },
  infoCardTitle: { fontSize: 10, fontWeight: '700', letterSpacing: 1, paddingHorizontal: 17, paddingVertical: 14, borderBottomWidth: 1 },
  infoRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 17, paddingVertical: 13, gap: 12 },
  infoLabel: { fontSize: 12.5 },
  infoVal: { fontSize: 12.5, fontWeight: '700', flexShrink: 1, textAlign: 'right' },

  rowCard: { borderRadius: 18, borderWidth: 1, overflow: 'hidden' },
  rowHead: { flexDirection: 'row', alignItems: 'center', gap: 12, padding: 15 },
  rowIcon: { width: 38, height: 38, borderRadius: 12, alignItems: 'center', justifyContent: 'center', flexShrink: 0 },
  rowTitle: { fontSize: 13, fontWeight: '700' },
  rowSub: { fontSize: 10.5, fontWeight: '600', marginTop: 1 },
  pwdForm: { paddingHorizontal: 17, paddingBottom: 16, paddingTop: 12, gap: 10, borderTopWidth: 1 },
  pwdHint: { fontSize: 11, lineHeight: 16 },
  input: { borderRadius: 12, padding: 13, fontSize: 13, borderWidth: 1 },
  btnSavePwd: { backgroundColor: '#E9A84C', borderRadius: 12, padding: 13, alignItems: 'center' },
  btnSavePwdText: { color: '#23282F', fontSize: 13, fontWeight: '800' },

  btnLogout: {
    backgroundColor: 'rgba(196,58,47,0.09)', borderWidth: 1, borderColor: 'rgba(196,58,47,0.30)',
    borderRadius: 18, padding: 15, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8,
  },
  btnLogoutText: { fontSize: 13, fontWeight: '700' },

  cropOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.7)', alignItems: 'center', justifyContent: 'center', padding: 24 },
  cropBox: { borderRadius: 24, padding: 24, width: '100%', gap: 16, alignItems: 'center' },
  cropTitle: { fontSize: 17, fontWeight: '800' },
  cropPreview: { width: 200, height: 200, borderRadius: 100 },
  cropHint: { fontSize: 12, textAlign: 'center', lineHeight: 18 },
  cropActions: { flexDirection: 'row', gap: 12, width: '100%' },
  cropBtnCancel: { flex: 1, borderRadius: 12, padding: 13, alignItems: 'center', borderWidth: 1 },
  cropBtnCancelTxt: { fontSize: 13, fontWeight: '600' },
  cropBtnConfirm: { flex: 1, backgroundColor: '#C43A2F', borderRadius: 12, padding: 13, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6 },
  cropBtnConfirmTxt: { color: '#fff', fontSize: 13, fontWeight: '700' },
});
