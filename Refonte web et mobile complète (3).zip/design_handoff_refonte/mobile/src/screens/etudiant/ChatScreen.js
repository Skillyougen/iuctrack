import React, { useState, useRef, useEffect } from 'react';
import {
  View, Text, TextInput, TouchableOpacity,
  StyleSheet, FlatList, ActivityIndicator,
  KeyboardAvoidingView, Platform, SafeAreaView
} from 'react-native';
import { Feather } from '@expo/vector-icons';
import { useSettings } from '../../context/SettingsContext';
import api from '../../services/api';

// v2 — IUCBot : avatar rouge (icône cpu), statut or, bulles bot en carte /
// bulles user rouges, suggestions en pills or, input pilule + envoi rond rouge.
// Logique conservée : POST /ia/chat avec historique, suggestions, indicateur de frappe.

const SUGGESTIONS = [
  "Quels types de demandes puis-je faire ?",
  "Comment suivre ma demande ?",
  "Quels documents dois-je fournir ?",
  "Quels sont les délais de traitement ?",
  "Comment me connecter à IUCTrack ?",
  "Quelles sont les écoles de l'IUC ?",
];

export default function ChatScreen({ navigation }) {
  const { colors, langue } = useSettings();
  const fr = langue === 'fr';
  const [messages, setMessages] = useState([]);
  const [input, setInput]       = useState('');
  const [loading, setLoading]   = useState(false);
  const flatListRef             = useRef(null);

  useEffect(() => {
    setMessages([{
      id: '0',
      role: 'assistant',
      content: fr
        ? "Bonjour ! Je suis **IUCBot**, l'assistant intelligent de la plateforme IUCTrack. 👋\n\nJe peux vous aider sur :\n• Les types de demandes disponibles\n• Le suivi de vos demandes\n• Les informations sur l'IUC\n• Le fonctionnement d'IUCTrack\n\nComment puis-je vous aider ?"
        : "Hello! I'm **IUCBot**, the IUCTrack intelligent assistant. 👋\n\nI can help you with:\n• Available request types\n• Tracking your requests\n• Information about IUC\n• How IUCTrack works\n\nHow can I help you?",
    }]);
  }, []);

  const sendMessage = async (text) => {
    const messageText = (text || input).trim();
    if (!messageText || loading) return;
    setInput('');
    const userMsg = { id: Date.now().toString(), role: 'user', content: messageText };
    const newMessages = [...messages, userMsg];
    setMessages(newMessages);
    setLoading(true);
    setTimeout(() => flatListRef.current?.scrollToEnd({ animated: true }), 100);
    try {
      const historique = newMessages
        .filter(m => m.id !== '0')
        .map(m => ({ role: m.role, content: m.content }));
      const res = await api.post('/ia/chat', {
        message: messageText,
        historique: historique.slice(0, -1),
      });
      const botMsg = { id: (Date.now() + 1).toString(), role: 'assistant', content: res.data.reponse };
      setMessages(prev => [...prev, botMsg]);
      setTimeout(() => flatListRef.current?.scrollToEnd({ animated: true }), 100);
    } catch (e) {
      setMessages(prev => [...prev, {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: fr
          ? 'Désolé, je rencontre une difficulté technique. Veuillez réessayer dans quelques instants.'
          : "Sorry, I'm experiencing a technical issue. Please try again in a moment.",
        isError: true,
      }]);
    } finally {
      setLoading(false);
    }
  };

  const BotAvatar = ({ size = 28 }) => (
    <View style={[S.botAvatar, { width: size, height: size, borderRadius: size / 2 }]}>
      <Feather name="cpu" size={size * 0.46} color="#FFFFFF" />
    </View>
  );

  const renderMessage = ({ item }) => {
    const isUser = item.role === 'user';
    if (isUser) {
      return (
        <View style={S.rowUser}>
          <View style={S.bubbleUser}>
            {renderFormattedText(item.content, true, colors)}
          </View>
        </View>
      );
    }
    return (
      <View style={S.rowBot}>
        <BotAvatar />
        <View style={[
          S.bubbleBot,
          { backgroundColor: colors.card, borderColor: colors.border },
          item.isError && { borderColor: 'rgba(196,58,47,0.35)', backgroundColor: 'rgba(196,58,47,0.08)' },
        ]}>
          {renderFormattedText(item.content, false, colors)}
        </View>
      </View>
    );
  };

  return (
    <SafeAreaView style={[S.root, { backgroundColor: colors.bg }]}>
      {/* HEADER */}
      <View style={[S.header, { borderBottomColor: colors.border }]}>
        <TouchableOpacity
          onPress={() => navigation.goBack()}
          style={[S.backBtn, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Feather name="chevron-left" size={18} color={colors.text} />
        </TouchableOpacity>
        <View style={S.headerAvatarWrap}>
          <BotAvatar size={40} />
        </View>
        <View style={{ flex: 1 }}>
          <Text style={[S.headerName, { color: colors.text }]}>IUCBot</Text>
          <View style={S.statusRow}>
            <View style={S.statusDot} />
            <Text style={[S.statusText, { color: colors.gold }]}>
              {fr ? "Assistant IA de l'IUC" : 'IUC AI assistant'}
            </Text>
          </View>
        </View>
        <TouchableOpacity
          onPress={() => setMessages([{
            id: '0', role: 'assistant',
            content: fr ? 'Bonjour ! Je suis IUCBot. Comment puis-je vous aider ?' : "Hello! I'm IUCBot. How can I help you?",
          }])}
          style={S.clearBtn}>
          <Feather name="refresh-ccw" size={15} color={colors.muted} />
        </TouchableOpacity>
      </View>

      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : 20}>
        {/* MESSAGES */}
        <FlatList
          ref={flatListRef}
          data={messages}
          keyExtractor={item => item.id}
          renderItem={renderMessage}
          contentContainerStyle={S.messageList}
          showsVerticalScrollIndicator={false}
          onContentSizeChange={() => flatListRef.current?.scrollToEnd({ animated: true })}
          ListFooterComponent={loading ? (
            <View style={S.rowBot}>
              <BotAvatar />
              <View style={[S.bubbleBot, { backgroundColor: colors.card, borderColor: colors.border }]}>
                <View style={S.typingRow}>
                  {[0, 1, 2].map(i => (
                    <View key={i} style={[S.typingDot, { backgroundColor: colors.muted }]} />
                  ))}
                </View>
              </View>
            </View>
          ) : null}
        />

        {/* SUGGESTIONS — pills or */}
        {messages.length <= 1 && !loading && (
          <View style={S.suggestionsWrap}>
            <FlatList
              data={SUGGESTIONS}
              keyExtractor={(_, i) => i.toString()}
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={S.suggestionsList}
              renderItem={({ item }) => (
                <TouchableOpacity
                  onPress={() => sendMessage(item)}
                  style={S.suggestionChip}
                  activeOpacity={0.8}>
                  <Text style={[S.suggestionText, { color: colors.gold }]}>{item}</Text>
                </TouchableOpacity>
              )}
            />
          </View>
        )}

        {/* INPUT — pilule + envoi rond rouge */}
        <View style={[S.inputWrap, { backgroundColor: colors.bg, borderTopColor: colors.border }]}>
          <TextInput
            style={[S.input, { backgroundColor: colors.input, color: colors.text, borderColor: colors.border }]}
            placeholder={fr ? 'Écrivez votre question…' : 'Type your question…'}
            placeholderTextColor={colors.muted}
            value={input}
            onChangeText={setInput}
            multiline
            maxLength={500}
            onSubmitEditing={() => sendMessage()}
            returnKeyType="send"
          />
          <TouchableOpacity
            onPress={() => sendMessage()}
            disabled={!input.trim() || loading}
            style={[S.sendBtn, { opacity: input.trim() && !loading ? 1 : 0.5 }]}
            activeOpacity={0.85}>
            <Feather name="send" size={16} color="#fff" />
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

// Rendu du texte formaté (gras avec **)
function renderFormattedText(text, isUser, colors) {
  const parts = text.split(/(\*\*[^*]+\*\*)/g);
  return (
    <Text style={{ fontSize: 12.5, lineHeight: 20, color: isUser ? '#fff' : colors.text }}>
      {parts.map((part, i) => {
        if (part.startsWith('**') && part.endsWith('**')) {
          return <Text key={i} style={{ fontWeight: '800' }}>{part.slice(2, -2)}</Text>;
        }
        return <Text key={i}>{part}</Text>;
      })}
    </Text>
  );
}

const S = StyleSheet.create({
  root: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', gap: 11, paddingHorizontal: 20, paddingTop: 12, paddingBottom: 12, borderBottomWidth: 1 },
  backBtn: { width: 36, height: 36, borderRadius: 12, alignItems: 'center', justifyContent: 'center', borderWidth: 1 },
  headerAvatarWrap: { flexShrink: 0 },
  botAvatar: { backgroundColor: '#C43A2F', alignItems: 'center', justifyContent: 'center', flexShrink: 0 },
  headerName: { fontSize: 13.5, fontWeight: '800' },
  statusRow: { flexDirection: 'row', alignItems: 'center', gap: 5, marginTop: 1 },
  statusDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: '#E9A84C' },
  statusText: { fontSize: 10.5 },
  clearBtn: { padding: 8 },
  messageList: { padding: 20, gap: 10 },
  rowBot: { flexDirection: 'row', alignItems: 'flex-start', gap: 9, maxWidth: '86%', alignSelf: 'flex-start' },
  rowUser: { alignSelf: 'flex-end', maxWidth: '78%' },
  bubbleBot: { flex: 1, padding: 12, borderRadius: 16, borderBottomLeftRadius: 5, borderWidth: 1, marginTop: 2 },
  bubbleUser: { backgroundColor: '#C43A2F', padding: 12, borderRadius: 16, borderBottomRightRadius: 5 },
  typingRow: { flexDirection: 'row', gap: 4, alignItems: 'center', paddingVertical: 4 },
  typingDot: { width: 6, height: 6, borderRadius: 3 },
  suggestionsWrap: { paddingBottom: 8 },
  suggestionsList: { paddingHorizontal: 20, gap: 8 },
  suggestionChip: {
    borderRadius: 999, paddingHorizontal: 15, paddingVertical: 9,
    borderWidth: 1, borderColor: 'rgba(233,168,76,0.45)',
    backgroundColor: 'rgba(233,168,76,0.08)', maxWidth: 240,
  },
  suggestionText: { fontSize: 12, fontWeight: '600' },
  inputWrap: { flexDirection: 'row', alignItems: 'flex-end', paddingHorizontal: 20, paddingVertical: 12, gap: 9, borderTopWidth: 1 },
  input: { flex: 1, borderRadius: 24, paddingHorizontal: 17, paddingVertical: 12, fontSize: 13, borderWidth: 1, maxHeight: 100 },
  sendBtn: {
    width: 44, height: 44, borderRadius: 22, backgroundColor: '#C43A2F',
    alignItems: 'center', justifyContent: 'center', flexShrink: 0,
  },
});
