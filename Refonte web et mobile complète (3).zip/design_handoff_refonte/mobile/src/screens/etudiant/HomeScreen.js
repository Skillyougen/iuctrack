import React, { useState, useCallback } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity,
  StyleSheet, ActivityIndicator, Image, RefreshControl
} from 'react-native';
import { Feather } from '@expo/vector-icons';
import { useFocusEffect } from '@react-navigation/native';
import { useAuth } from '../../context/AuthContext';
import { useSettings } from '../../context/SettingsContext';
import api from '../../services/api';

const BASE_URL = 'http://192.168.137.1:8000/storage/';

// v2 — Accueil : header logo+avatar, grand titre 2 lignes, bannière IUCBot rouge,
// grille 2×2 (4e carte = panneau vert), « Suivi en cours » avec vraies demandes + barres 3 segments.

export default function HomeScreen({ navigation }) {
  const { etudiant } = useAuth();
  const { colors, t, langue } = useSettings();
  const fr = langue === 'fr';
  const [demandes, setDemandes] = useState([]);
  const [nonLuesNotifs, setNonLuesNotifs] = useState(0);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const STATUTS = {
    envoyee:  { label: t.envoyee,  color: '#6B8FCB', bg: 'rgba(107,143,203,0.16)' },
    en_cours: { label: t.encours,  color: '#E9A84C', bg: 'rgba(233,168,76,0.16)'  },
    terminee: { label: t.terminee, color: '#22A06B', bg: 'rgba(34,160,107,0.16)'  },
  };

  useFocusEffect(useCallback(() => { fetchData(); }, []));

  const fetchData = async () => {
    try {
      const [dRes, nRes] = await Promise.all([
        api.get('/etudiant/demandes'),
        api.get('/etudiant/notifications').catch(() => ({ data: [] })),
      ]);
      setDemandes(dRes.data);
      setNonLuesNotifs((nRes.data || []).filter(n => !n.lue).length);
    } catch (e) { console.error(e); }
    finally { setLoading(false); setRefreshing(false); }
  };

  // Suivi en cours = demandes réelles non terminées (2 max)
  const suivi = demandes.filter(d => d.statut !== 'terminee').slice(0, 2);

  const photoUri = etudiant?.photo ? BASE_URL + etudiant.photo : null;
  const initiales = `${etudiant?.nom?.charAt(0) || ''}${etudiant?.prenom?.charAt(0) || ''}`;

  const segColor = (d, i) => {
    const rank = d.statut === 'envoyee' ? 1 : d.statut === 'en_cours' ? 2 : 3;
    return i < rank ? STATUTS[d.statut].color : colors.border;
  };

  return (
    <View style={[S.root, { backgroundColor: colors.bg }]}>
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={S.scroll}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); fetchData(); }} tintColor="#C43A2F" />}
      >
        {/* HEADER — logo + salutation + avatar */}
        <View style={S.header}>
          <Image source={require('../../../assets/images/logo-icon.png')} style={S.logo} resizeMode="contain" />
          <TouchableOpacity style={S.avatarWrap} onPress={() => navigation.navigate(t.profil)} activeOpacity={0.8}>
            <View style={{ alignItems: 'flex-end' }}>
              <Text style={[S.helloText, { color: colors.muted }]}>{t.bonjour},</Text>
              <Text style={[S.nameText, { color: colors.text }]}>{etudiant?.prenom}</Text>
            </View>
            {photoUri ? (
              <Image source={{ uri: photoUri }} style={S.avatarCircle} />
            ) : (
              <View style={[S.avatarCircle, { backgroundColor: '#C43A2F' }]}>
                <Text style={S.avatarText}>{initiales}</Text>
              </View>
            )}
          </TouchableOpacity>
        </View>

        {/* GRAND TITRE — 2 lignes */}
        <Text style={[S.bigTitle, { color: colors.text }]}>
          {fr ? 'Vos\nDemandes' : 'Your\nRequests'}
        </Text>

        {/* BANNIÈRE IUCBOT */}
        <TouchableOpacity onPress={() => navigation.navigate('Chat')} activeOpacity={0.85} style={S.chatBanner}>
          <View style={S.chatBannerLeft}>
            <View style={S.chatBannerIcon}>
              <Feather name="cpu" size={20} color="#fff" />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={S.chatBannerTitle}>IUCBot — {fr ? 'Assistant IA' : 'AI Assistant'}</Text>
              <Text style={S.chatBannerSub}>
                {fr ? "Posez vos questions sur l'IUC et vos demandes" : 'Ask about IUC and your requests'}
              </Text>
            </View>
          </View>
          <View style={S.chatBannerArrow}>
            <Feather name="chevron-right" size={15} color="#fff" />
          </View>
        </TouchableOpacity>

        {/* GRILLE 2×2 */}
        <View style={S.grid}>
          <TouchableOpacity
            style={[S.card, { backgroundColor: colors.card, borderColor: colors.border }]}
            onPress={() => navigation.navigate('ChoixTypeDemandeScreen')} activeOpacity={0.8}>
            <View style={[S.cardIconWrap, { backgroundColor: 'rgba(196,58,47,0.13)' }]}>
              <Feather name="plus-circle" size={24} color={colors.redInk} />
            </View>
            <Text style={[S.cardLabel, { color: colors.text }]}>{fr ? 'Nouvelle\ndemande' : 'New\nrequest'}</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[S.card, { backgroundColor: colors.card, borderColor: colors.border }]}
            onPress={() => navigation.navigate(t.demandes)} activeOpacity={0.8}>
            <View style={[S.cardIconWrap, { backgroundColor: 'rgba(34,160,107,0.13)' }]}>
              <Feather name="folder" size={24} color={colors.greenInk} />
            </View>
            <Text style={[S.cardLabel, { color: colors.text }]}>{fr ? 'Mes\ndemandes' : 'My\nrequests'}</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[S.card, { backgroundColor: colors.card, borderColor: colors.border }]}
            onPress={() => navigation.navigate(t.notifications)} activeOpacity={0.8}>
            <View style={[S.cardIconWrap, { backgroundColor: 'rgba(107,143,203,0.14)' }]}>
              <Feather name="bell" size={24} color={colors.blue} />
              {nonLuesNotifs > 0 && (
                <View style={S.cardBadge}><Text style={S.cardBadgeText}>{nonLuesNotifs}</Text></View>
              )}
            </View>
            <Text style={[S.cardLabel, { color: colors.text }]}>Notifications</Text>
          </TouchableOpacity>

          {/* 4e carte — panneau vert sombre */}
          <TouchableOpacity
            style={[S.card, { backgroundColor: colors.panel, borderColor: colors.panel }]}
            onPress={() => navigation.navigate(t.profil)} activeOpacity={0.8}>
            <View style={[S.cardIconWrap, { backgroundColor: 'rgba(240,237,228,0.12)' }]}>
              <Feather name="user" size={24} color={colors.panelInk} />
            </View>
            <Text style={[S.cardLabel, { color: colors.panelInk }]}>{fr ? 'Mon\nprofil' : 'My\nprofile'}</Text>
          </TouchableOpacity>
        </View>

        {/* SUIVI EN COURS — demandes réelles */}
        <View style={S.sectionHeader}>
          <Text style={[S.sectionTitle, { color: colors.text }]}>{t.suivicours}</Text>
          <TouchableOpacity onPress={() => navigation.navigate(t.demandes)}>
            <Text style={[S.seeAllText, { color: colors.redInk }]}>{t.voirtout}</Text>
          </TouchableOpacity>
        </View>

        {loading ? (
          <ActivityIndicator color="#C43A2F" style={{ marginTop: 20 }} />
        ) : suivi.length === 0 ? (
          <View style={[S.emptyCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Feather name="inbox" size={22} color={colors.muted} />
            <Text style={{ fontSize: 12, color: colors.muted }}>
              {fr ? 'Aucune demande en cours de traitement.' : 'No request currently being processed.'}
            </Text>
          </View>
        ) : suivi.map((d) => {
          const s = STATUTS[d.statut];
          return (
            <TouchableOpacity
              key={d.id}
              style={[S.trackCard, { backgroundColor: colors.card, borderColor: colors.border }]}
              onPress={() => navigation.navigate('DetailDemandeScreen', { demande: d })}
              activeOpacity={0.8}>
              <View style={S.trackTop}>
                <View style={[S.trackIcon, { backgroundColor: s.bg }]}>
                  <Feather name="file-text" size={17} color={s.color} />
                </View>
                <View style={{ flex: 1, minWidth: 0 }}>
                  <Text style={[S.trackType, { color: colors.text }]} numberOfLines={1}>{d.type_demande?.libelle}</Text>
                  <Text style={[S.trackRef, { color: colors.muted }]}>
                    DEM-{new Date(d.created_at).getFullYear()}-{String(d.id).padStart(4, '0')} · {new Date(d.created_at).toLocaleDateString(fr ? 'fr-FR' : 'en-US')}
                  </Text>
                </View>
                <View style={[S.trackPill, { backgroundColor: s.bg }]}>
                  <Text style={[S.trackPillText, { color: s.color }]}>{s.label}</Text>
                </View>
              </View>
              <View style={S.segRow}>
                {[0, 1, 2].map(i => (
                  <View key={i} style={[S.seg, { backgroundColor: segColor(d, i) }]} />
                ))}
              </View>
              <View style={S.segLabels}>
                <Text style={[S.segLabel, { color: colors.muted }]}>{t.envoyee}</Text>
                <Text style={[S.segLabel, { color: colors.muted }]}>{t.encours}</Text>
                <Text style={[S.segLabel, { color: colors.muted }]}>{fr ? 'Terminée' : 'Done'}</Text>
              </View>
            </TouchableOpacity>
          );
        })}

        <View style={{ height: 120 }} />
      </ScrollView>
    </View>
  );
}

const S = StyleSheet.create({
  root: { flex: 1 },
  scroll: { paddingHorizontal: 22 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingTop: 56, marginBottom: 18 },
  logo: { width: 36, height: 36, borderRadius: 10, backgroundColor: '#FFFFFF' },
  avatarWrap: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  avatarCircle: { width: 42, height: 42, borderRadius: 21, alignItems: 'center', justifyContent: 'center', borderWidth: 2, borderColor: '#E9A84C' },
  avatarText: { color: '#fff', fontSize: 13, fontWeight: '800' },
  helloText: { fontSize: 10.5 },
  nameText: { fontSize: 13.5, fontWeight: '800' },
  bigTitle: { fontSize: 40, fontWeight: '800', lineHeight: 42, letterSpacing: -1.2, marginBottom: 16 },

  chatBanner: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 12,
    backgroundColor: '#C43A2F', borderRadius: 20, padding: 15, marginBottom: 20,
    shadowColor: '#C43A2F', shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.35, shadowRadius: 18, elevation: 8,
  },
  chatBannerLeft: { flexDirection: 'row', alignItems: 'center', gap: 12, flex: 1 },
  chatBannerIcon: { width: 44, height: 44, borderRadius: 22, backgroundColor: 'rgba(255,255,255,0.16)', alignItems: 'center', justifyContent: 'center' },
  chatBannerTitle: { fontSize: 14, fontWeight: '800', color: '#fff' },
  chatBannerSub: { fontSize: 11, color: 'rgba(255,255,255,0.78)', marginTop: 2, lineHeight: 15 },
  chatBannerArrow: { width: 30, height: 30, borderRadius: 15, backgroundColor: 'rgba(255,255,255,0.16)', alignItems: 'center', justifyContent: 'center' },

  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12, marginBottom: 24 },
  card: {
    width: '47.5%', borderRadius: 22, padding: 16, borderWidth: 1.5,
    gap: 26, flexGrow: 1,
  },
  cardIconWrap: { width: 50, height: 50, borderRadius: 15, alignItems: 'center', justifyContent: 'center' },
  cardBadge: {
    position: 'absolute', top: -4, right: -4, minWidth: 18, height: 18, borderRadius: 10,
    backgroundColor: '#C43A2F', alignItems: 'center', justifyContent: 'center', paddingHorizontal: 5,
  },
  cardBadgeText: { color: '#fff', fontSize: 10, fontWeight: '800' },
  cardLabel: { fontSize: 13.5, fontWeight: '700', lineHeight: 17 },

  sectionHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 },
  sectionTitle: { fontSize: 17, fontWeight: '800', letterSpacing: -0.3 },
  seeAllText: { fontSize: 12, fontWeight: '700' },
  emptyCard: { borderRadius: 18, borderWidth: 1, padding: 18, alignItems: 'center', gap: 8, marginTop: 9 },

  trackCard: { borderRadius: 18, borderWidth: 1, padding: 15, marginTop: 9 },
  trackTop: { flexDirection: 'row', alignItems: 'center', gap: 11 },
  trackIcon: { width: 40, height: 40, borderRadius: 13, alignItems: 'center', justifyContent: 'center', flexShrink: 0 },
  trackType: { fontSize: 13, fontWeight: '700' },
  trackRef: { fontSize: 10.5, marginTop: 2 },
  trackPill: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 999, flexShrink: 0 },
  trackPillText: { fontSize: 10, fontWeight: '700' },
  segRow: { flexDirection: 'row', gap: 5, marginTop: 13 },
  seg: { flex: 1, height: 5, borderRadius: 3 },
  segLabels: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 5 },
  segLabel: { fontSize: 9.5, fontWeight: '600' },
});
