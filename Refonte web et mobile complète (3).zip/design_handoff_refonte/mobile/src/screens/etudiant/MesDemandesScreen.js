import React, { useState, useCallback } from 'react';
import {
  View, Text, StyleSheet, ScrollView,
  TouchableOpacity, ActivityIndicator, RefreshControl
} from 'react-native';
import { Feather } from '@expo/vector-icons';
import { useFocusEffect } from '@react-navigation/native';
import { useSettings } from '../../context/SettingsContext';
import api from '../../services/api';

// v2 — Mes demandes : titre + FAB rouge, pills de filtre, cartes avec
// icône teintée statut, réf DEM-YYYY-XXXX, pastille statut, barre 3 segments.

export default function MesDemandesScreen({ navigation }) {
  const { colors, t, langue } = useSettings();
  const fr = langue === 'fr';
  const [demandes, setDemandes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [filtre, setFiltre] = useState('all');

  const STATUTS = {
    envoyee:  { label: t.envoyee,  color: '#6B8FCB', bg: 'rgba(107,143,203,0.16)' },
    en_cours: { label: t.encours,  color: '#E9A84C', bg: 'rgba(233,168,76,0.16)'  },
    terminee: { label: t.terminee, color: '#22A06B', bg: 'rgba(34,160,107,0.16)'  },
  };

  useFocusEffect(useCallback(() => { fetchDemandes(); }, []));

  const fetchDemandes = async () => {
    try {
      const res = await api.get('/etudiant/demandes');
      setDemandes(res.data);
    } catch (e) { console.error(e); }
    finally { setLoading(false); setRefreshing(false); }
  };

  const filtered = filtre === 'all' ? demandes : demandes.filter(d => d.statut === filtre);

  const FILTRES = [
    { key: 'all',      label: fr ? 'Toutes' : 'All' },
    { key: 'envoyee',  label: t.envoyee },
    { key: 'en_cours', label: t.encours },
    { key: 'terminee', label: t.terminee },
  ];

  const segColor = (d, i) => {
    const rank = d.statut === 'envoyee' ? 1 : d.statut === 'en_cours' ? 2 : 3;
    return i < rank ? STATUTS[d.statut].color : colors.border;
  };

  if (loading) {
    return (
      <View style={[S.centered, { backgroundColor: colors.bg }]}>
        <ActivityIndicator size="large" color="#C43A2F" />
      </View>
    );
  }

  return (
    <View style={[S.root, { backgroundColor: colors.bg }]}>
      {/* HEADER — titre + FAB rouge */}
      <View style={S.header}>
        <View>
          <Text style={[S.bigTitle, { color: colors.text }]}>{fr ? 'Mes demandes' : 'My requests'}</Text>
          <Text style={[S.subTitle, { color: colors.muted }]}>
            {demandes.length} {fr ? 'demandes au total' : 'requests in total'}
          </Text>
        </View>
        <TouchableOpacity
          style={S.fab}
          onPress={() => navigation.navigate('ChoixTypeDemandeScreen')}
          activeOpacity={0.85}>
          <Feather name="plus" size={18} color="#fff" />
        </TouchableOpacity>
      </View>

      {/* FILTRES — pills */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={S.filtersScroll} contentContainerStyle={S.filtersRow}>
        {FILTRES.map(f => {
          const active = filtre === f.key;
          return (
            <TouchableOpacity
              key={f.key}
              onPress={() => setFiltre(f.key)}
              style={[S.filterPill, {
                backgroundColor: active ? '#C43A2F' : colors.card,
                borderColor: active ? '#C43A2F' : colors.border,
              }]}>
              <Text style={{ fontSize: 12, fontWeight: active ? '700' : '600', color: active ? '#fff' : colors.muted }}>
                {f.label}
              </Text>
            </TouchableOpacity>
          );
        })}
      </ScrollView>

      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={S.scroll}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); fetchDemandes(); }} tintColor="#C43A2F" />}>
        {filtered.length === 0 ? (
          <View style={S.emptyWrap}>
            <Feather name="inbox" size={40} color={colors.muted} />
            <Text style={[S.emptyTitle, { color: colors.text }]}>{t.aucunedemande}</Text>
          </View>
        ) : filtered.map((demande) => {
          const s = STATUTS[demande.statut];
          return (
            <TouchableOpacity
              key={demande.id}
              style={[S.card, { backgroundColor: colors.card, borderColor: colors.border }]}
              onPress={() => navigation.navigate('DetailDemandeScreen', { demande })}
              activeOpacity={0.8}>
              <View style={S.cardTop}>
                <View style={[S.cardIcon, { backgroundColor: s.bg }]}>
                  <Feather name="file-text" size={18} color={s.color} />
                </View>
                <View style={{ flex: 1, minWidth: 0 }}>
                  <Text style={[S.cardType, { color: colors.text }]}>{demande.type_demande?.libelle}</Text>
                  <Text style={[S.cardRef, { color: colors.muted }]}>
                    DEM-{new Date(demande.created_at).getFullYear()}-{String(demande.id).padStart(4, '0')} · {demande.documents_joints?.length || 0} docs
                  </Text>
                </View>
                <View style={{ alignItems: 'flex-end', gap: 4 }}>
                  <View style={[S.pill, { backgroundColor: s.bg }]}>
                    <Text style={[S.pillText, { color: s.color }]}>{s.label}</Text>
                  </View>
                  <Text style={[S.cardDate, { color: colors.muted }]}>
                    {new Date(demande.created_at).toLocaleDateString(fr ? 'fr-FR' : 'en-US')}
                  </Text>
                </View>
              </View>
              <View style={S.segRow}>
                {[0, 1, 2].map(i => (
                  <View key={i} style={[S.seg, { backgroundColor: segColor(demande, i) }]} />
                ))}
              </View>
            </TouchableOpacity>
          );
        })}
        <View style={{ height: 120 }} />
      </ScrollView>
    </View>
  );
}

const S = StyleSheet.create({
  root: { flex: 1 },
  centered: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-end', paddingHorizontal: 22, paddingTop: 56, paddingBottom: 14 },
  bigTitle: { fontSize: 26, fontWeight: '800', letterSpacing: -0.5 },
  subTitle: { fontSize: 11.5, marginTop: 2 },
  fab: {
    width: 42, height: 42, borderRadius: 14, backgroundColor: '#C43A2F',
    alignItems: 'center', justifyContent: 'center',
    shadowColor: '#C43A2F', shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.35, shadowRadius: 14, elevation: 7,
  },
  filtersScroll: { flexGrow: 0, marginBottom: 14 },
  filtersRow: { paddingHorizontal: 22, gap: 7 },
  filterPill: { paddingHorizontal: 15, paddingVertical: 8, borderRadius: 999, borderWidth: 1 },
  scroll: { paddingHorizontal: 22, gap: 10 },
  emptyWrap: { alignItems: 'center', gap: 12, marginTop: 60 },
  emptyTitle: { fontSize: 16, fontWeight: '700' },
  card: { borderRadius: 18, borderWidth: 1, padding: 15 },
  cardTop: { flexDirection: 'row', alignItems: 'center', gap: 11 },
  cardIcon: { width: 42, height: 42, borderRadius: 13, alignItems: 'center', justifyContent: 'center', flexShrink: 0 },
  cardType: { fontSize: 13.5, fontWeight: '700' },
  cardRef: { fontSize: 10.5, marginTop: 2 },
  pill: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 999 },
  pillText: { fontSize: 10, fontWeight: '700' },
  cardDate: { fontSize: 10 },
  segRow: { flexDirection: 'row', gap: 5, marginTop: 13 },
  seg: { flex: 1, height: 5, borderRadius: 3 },
});
