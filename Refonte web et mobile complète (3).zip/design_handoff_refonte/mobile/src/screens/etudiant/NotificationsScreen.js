import React, { useState, useCallback } from 'react';
import {
  View, Text, StyleSheet, ScrollView,
  TouchableOpacity, ActivityIndicator, RefreshControl
} from 'react-native';
import { Feather } from '@expo/vector-icons';
import { useFocusEffect } from '@react-navigation/native';
import { useSettings } from '../../context/SettingsContext';
import api from '../../services/api';

// v2 — Notifications : titre + « N non lues », bouton « Tout marquer lu » vert,
// icônes teintées selon le type de message, non lue = bordure rouge + point.

// Déduit la teinte de l'icône depuis le titre réel de la notification
function deriveKind(titre = '') {
  const s = titre.toLowerCase();
  if (/(illisible|manquant|expir|incorrect|refus)/.test(s)) return 'warn';
  if (/(en cours|progress|envoy)/.test(s)) return 'info';
  return 'ok';
}

export default function NotificationsScreen() {
  const { colors, t, langue } = useSettings();
  const fr = langue === 'fr';
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  useFocusEffect(useCallback(() => { fetchNotifications(); }, []));

  const fetchNotifications = async () => {
    try {
      const res = await api.get('/etudiant/notifications');
      setNotifications(res.data);
    } catch (e) { console.error(e); }
    finally { setLoading(false); setRefreshing(false); }
  };

  const marquerLue = async (id) => {
    try {
      await api.put(`/etudiant/notifications/${id}/lue`);
      setNotifications(prev => prev.map(n => n.id === id ? { ...n, lue: true } : n));
    } catch (e) { console.error(e); }
  };

  const marquerToutesLues = async () => {
    try {
      await api.put('/etudiant/notifications/toutes-lues');
      setNotifications(prev => prev.map(n => ({ ...n, lue: true })));
    } catch (e) { console.error(e); }
  };

  const nonLues = notifications.filter(n => !n.lue).length;

  const KIND_STYLE = {
    warn: { bg: 'rgba(196,58,47,0.13)',  color: colors.redInk },
    info: { bg: 'rgba(233,168,76,0.14)', color: colors.gold },
    ok:   { bg: 'rgba(34,160,107,0.14)', color: colors.greenInk },
  };

  if (loading) {
    return (
      <View style={[S.centered, { backgroundColor: colors.bg }]}>
        <ActivityIndicator size="large" color="#C43A2F" />
      </View>
    );
  }

  return (
    <View style={[S.root, { backgroundColor: colors.bg }]}>
      <View style={S.header}>
        <View>
          <Text style={[S.bigTitle, { color: colors.text }]}>{t.notifications}</Text>
          <Text style={[S.subTitle, { color: colors.muted }]}>
            {nonLues} {fr ? `non lue${nonLues > 1 ? 's' : ''}` : 'unread'}
          </Text>
        </View>
        {nonLues > 0 && (
          <TouchableOpacity style={S.btnAllRead} onPress={marquerToutesLues} activeOpacity={0.8}>
            <Text style={[S.btnAllReadText, { color: colors.greenInk }]}>
              {fr ? 'Tout marquer lu' : 'Mark all read'}
            </Text>
          </TouchableOpacity>
        )}
      </View>

      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={S.scroll}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); fetchNotifications(); }} tintColor="#C43A2F" />}>
        {notifications.length === 0 ? (
          <View style={S.emptyWrap}>
            <Feather name="bell-off" size={40} color={colors.muted} />
            <Text style={[S.emptyTitle, { color: colors.text }]}>{t.aucunenotif}</Text>
          </View>
        ) : notifications.map((notif) => {
          const k = KIND_STYLE[deriveKind(notif.titre)];
          return (
            <TouchableOpacity
              key={notif.id}
              style={[S.card, {
                backgroundColor: colors.card,
                borderColor: !notif.lue ? 'rgba(196,58,47,0.30)' : colors.border,
              }]}
              onPress={() => marquerLue(notif.id)}
              activeOpacity={0.8}>
              <View style={[S.icon, { backgroundColor: k.bg }]}>
                <Feather name="bell" size={17} color={k.color} />
              </View>
              <View style={{ flex: 1, minWidth: 0 }}>
                <View style={S.cardTop}>
                  <Text style={[S.titre, { color: colors.text }]} numberOfLines={1}>{notif.titre}</Text>
                  {!notif.lue && <View style={S.unreadDot} />}
                </View>
                <Text style={[S.message, { color: colors.muted }]}>{notif.message}</Text>
                <Text style={[S.date, { color: colors.muted }]}>
                  {new Date(notif.created_at).toLocaleDateString(fr ? 'fr-FR' : 'en-US', {
                    day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit',
                  })}
                </Text>
              </View>
            </TouchableOpacity>
          );
        })}
        <View style={{ height: 120 }} />
      </ScrollView>
    </View>
  );
}

const S = StyleSheet.create({
  root: { flex: 1 },
  centered: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-end', paddingHorizontal: 22, paddingTop: 56, paddingBottom: 16 },
  bigTitle: { fontSize: 26, fontWeight: '800', letterSpacing: -0.5 },
  subTitle: { fontSize: 11.5, marginTop: 2 },
  btnAllRead: {
    borderWidth: 1, borderColor: 'rgba(34,160,107,0.40)', borderRadius: 999,
    paddingHorizontal: 13, paddingVertical: 7,
  },
  btnAllReadText: { fontSize: 11.5, fontWeight: '700' },
  scroll: { paddingHorizontal: 22, gap: 9 },
  emptyWrap: { alignItems: 'center', gap: 12, marginTop: 60 },
  emptyTitle: { fontSize: 16, fontWeight: '700' },
  card: { borderRadius: 18, borderWidth: 1, padding: 15, flexDirection: 'row', gap: 12, alignItems: 'flex-start' },
  icon: { width: 40, height: 40, borderRadius: 13, alignItems: 'center', justifyContent: 'center', flexShrink: 0 },
  cardTop: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  titre: { fontSize: 13, fontWeight: '700', flex: 1 },
  unreadDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: '#C43A2F', flexShrink: 0 },
  message: { fontSize: 11.5, lineHeight: 17, marginTop: 3 },
  date: { fontSize: 10, fontWeight: '600', marginTop: 6 },
});
