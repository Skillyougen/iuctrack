import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { Feather } from '@expo/vector-icons';
import { useSettings } from '../../context/SettingsContext';

// v2 — Paramètres : cartes thème (aperçu sombre #1B2026 / clair #F0EDE4),
// sélection = bordure rouge + point, cartes langue avec drapeaux, carte À propos.

export default function ParametresScreen({ navigation }) {
  const { colors, t, theme, langue, toggleTheme, toggleLangue } = useSettings();
  const fr = langue === 'fr';

  return (
    <View style={[S.root, { backgroundColor: colors.bg }]}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={S.scroll}>

        {/* HEADER */}
        <View style={S.header}>
          <TouchableOpacity
            onPress={() => navigation.goBack()}
            style={[S.backBtn, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Feather name="chevron-left" size={20} color={colors.text} />
          </TouchableOpacity>
          <Text style={[S.bigTitle, { color: colors.text }]}>{t.parametres}</Text>
        </View>

        {/* THÈME */}
        <View style={S.section}>
          <Text style={[S.sectionTitle, { color: colors.muted }]}>{t.theme.toUpperCase()}</Text>
          <View style={S.optionsRow}>
            <TouchableOpacity
              style={[S.optionCard, { backgroundColor: '#1B2026', borderColor: theme === 'dark' ? '#C43A2F' : colors.border }]}
              onPress={() => toggleTheme('dark')} activeOpacity={0.85}>
              <View style={[S.optionIcon, { backgroundColor: '#232A33' }]}>
                <Feather name="moon" size={17} color="#EDF1F5" />
              </View>
              <Text style={[S.optionLabel, { color: '#EDF1F5' }]}>{t.sombre}</Text>
              {theme === 'dark' && <View style={S.activeDot} />}
            </TouchableOpacity>

            <TouchableOpacity
              style={[S.optionCard, { backgroundColor: '#F0EDE4', borderColor: theme === 'light' ? '#C43A2F' : colors.border }]}
              onPress={() => toggleTheme('light')} activeOpacity={0.85}>
              <View style={[S.optionIcon, { backgroundColor: '#FFFFFF', borderWidth: 1, borderColor: 'rgba(35,40,47,0.10)' }]}>
                <Feather name="sun" size={17} color="#23282F" />
              </View>
              <Text style={[S.optionLabel, { color: '#23282F' }]}>{t.clair}</Text>
              {theme === 'light' && <View style={S.activeDot} />}
            </TouchableOpacity>
          </View>
        </View>

        {/* LANGUE */}
        <View style={S.section}>
          <Text style={[S.sectionTitle, { color: colors.muted }]}>{t.langue.toUpperCase()}</Text>
          <View style={S.optionsRow}>
            <TouchableOpacity
              style={[S.langCard, { backgroundColor: colors.card, borderColor: langue === 'fr' ? '#C43A2F' : colors.border }]}
              onPress={() => toggleLangue('fr')} activeOpacity={0.85}>
              <Text style={S.flagEmoji}>🇫🇷</Text>
              <Text style={[S.optionLabel, { color: colors.text }]}>{t.francais}</Text>
              {langue === 'fr' && <View style={S.activeDot} />}
            </TouchableOpacity>

            <TouchableOpacity
              style={[S.langCard, { backgroundColor: colors.card, borderColor: langue === 'en' ? '#C43A2F' : colors.border }]}
              onPress={() => toggleLangue('en')} activeOpacity={0.85}>
              <Text style={S.flagEmoji}>🇬🇧</Text>
              <Text style={[S.optionLabel, { color: colors.text }]}>{t.anglais}</Text>
              {langue === 'en' && <View style={S.activeDot} />}
            </TouchableOpacity>
          </View>
        </View>

        {/* À PROPOS */}
        <View style={S.section}>
          <Text style={[S.sectionTitle, { color: colors.muted }]}>{fr ? 'À PROPOS' : 'ABOUT'}</Text>
          <View style={[S.infoCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
            {[
              { label: 'Application', val: 'IUCTrack v2.0' },
              { label: fr ? 'Développé pour' : 'Built for', val: 'IUC Douala' },
              { label: 'Mobile', val: 'React Native + Expo' },
              { label: 'Backend', val: 'Laravel 12 + Sanctum' },
              { label: 'Support', val: 'support@iuctrack.cm', green: true },
            ].map((item, i, arr) => (
              <View key={i} style={[S.infoRow, { borderBottomColor: colors.border, borderBottomWidth: i < arr.length - 1 ? 1 : 0 }]}>
                <Text style={[S.infoLabel, { color: colors.muted }]}>{item.label}</Text>
                <Text style={[S.infoVal, { color: item.green ? colors.greenInk : colors.text }]}>{item.val}</Text>
              </View>
            ))}
          </View>
        </View>

        <View style={{ height: 40 }} />
      </ScrollView>
    </View>
  );
}

const S = StyleSheet.create({
  root: { flex: 1 },
  scroll: { paddingHorizontal: 22, gap: 22 },
  header: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingTop: 56, paddingBottom: 2 },
  backBtn: { width: 38, height: 38, borderRadius: 13, alignItems: 'center', justifyContent: 'center', borderWidth: 1 },
  bigTitle: { fontSize: 22, fontWeight: '800', letterSpacing: -0.5 },
  section: { gap: 9 },
  sectionTitle: { fontSize: 10, fontWeight: '700', letterSpacing: 1 },
  optionsRow: { flexDirection: 'row', gap: 10 },
  optionCard: { flex: 1, borderRadius: 18, padding: 15, gap: 10, borderWidth: 2, position: 'relative' },
  optionIcon: { width: 38, height: 38, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  langCard: { flex: 1, borderRadius: 18, padding: 15, flexDirection: 'row', alignItems: 'center', gap: 11, borderWidth: 2, position: 'relative' },
  flagEmoji: { fontSize: 22 },
  optionLabel: { fontSize: 13, fontWeight: '700' },
  activeDot: { position: 'absolute', top: 10, right: 10, width: 9, height: 9, borderRadius: 5, backgroundColor: '#C43A2F' },
  infoCard: { borderRadius: 18, borderWidth: 1, overflow: 'hidden' },
  infoRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 16, paddingVertical: 13 },
  infoLabel: { fontSize: 12.5 },
  infoVal: { fontSize: 12.5, fontWeight: '700' },
});
