import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { Feather } from '@expo/vector-icons';
import { useSettings } from '../../context/SettingsContext';

// v2 — Suivi « colis » : timeline enrichie (description + dates réelles created_at / updated_at),
// carte type sur panneau crème, documents joints avec pastille statut.

export default function DetailDemandeScreen({ route, navigation }) {
  const { demande } = route.params;
  const { colors, t, langue } = useSettings();
  const fr = langue === 'fr';

  const STATUTS = {
    envoyee:  { label: t.envoyee,  color: '#6B8FCB', bg: 'rgba(107,143,203,0.16)', icon: 'send' },
    en_cours: { label: t.encours,  color: '#E9A84C', bg: 'rgba(233,168,76,0.16)',  icon: 'clock' },
    terminee: { label: t.terminee, color: '#22A06B', bg: 'rgba(34,160,107,0.16)',  icon: 'check-circle' },
  };

  const s = STATUTS[demande.statut];
  const etapeIndex = ['envoyee', 'en_cours', 'terminee'].indexOf(demande.statut);

  const fmtDate = (d) => d
    ? new Date(d).toLocaleDateString(fr ? 'fr-FR' : 'en-US', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' })
    : '—';

  // Dates réelles : création = étape 1 ; updated_at = dernière transition
  const ETAPES = [
    { key: 'envoyee',  label: t.envoyee,  desc: t.etape1desc, date: fmtDate(demande.created_at) },
    { key: 'en_cours', label: t.encours,  desc: t.etape2desc, date: etapeIndex >= 1 ? fmtDate(demande.updated_at) : '—' },
    { key: 'terminee', label: t.terminee, desc: t.etape3desc, date: etapeIndex >= 2 ? fmtDate(demande.updated_at) : '—' },
  ];

  return (
    <View style={[styles.root, { backgroundColor: colors.bg }]}>
      {/* HEADER */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}
          style={[styles.backBtn, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Feather name="chevron-left" size={20} color={colors.text} />
        </TouchableOpacity>
        <View style={{ flex: 1 }}>
          <Text style={[styles.headerTitle, { color: colors.text }]}>{t.suivi}</Text>
          <Text style={[styles.headerSub, { color: colors.muted }]} numberOfLines={1}>
            {fr ? 'Demande' : 'Request'} #{demande.id}
          </Text>
        </View>
        <View style={[styles.statusPill, { backgroundColor: s.bg }]}>
          <Text style={[styles.statusPillText, { color: s.color }]}>{s.label}</Text>
        </View>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}>
        {/* CARTE TYPE — panneau contrasté */}
        <View style={[styles.typeCard, { backgroundColor: colors.panel }]}>
          <Text style={[styles.typeLabel, { color: colors.panelMuted }]}>
            {fr ? 'TYPE DE DEMANDE' : 'REQUEST TYPE'}
          </Text>
          <Text style={[styles.typeVal, { color: colors.panelInk }]}>{demande.type_demande?.libelle}</Text>
          <View style={styles.typeMeta}>
            <View style={styles.typeMetaItem}>
              <Feather name="calendar" size={11} color={colors.panelMuted} />
              <Text style={[styles.typeMetaText, { color: colors.panelMuted }]}>
                {new Date(demande.created_at).toLocaleDateString(fr ? 'fr-FR' : 'en-US')}
              </Text>
            </View>
            <View style={styles.typeMetaItem}>
              <Feather name="paperclip" size={11} color={colors.panelMuted} />
              <Text style={[styles.typeMetaText, { color: colors.panelMuted }]}>
                {demande.documents_joints?.length || 0} {t.documentsjoints.toLowerCase()}
              </Text>
            </View>
          </View>
        </View>

        {/* TIMELINE — dates réelles */}
        <View style={[styles.sectionCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Text style={[styles.sectionTitle, { color: colors.muted }]}>{t.progression.toUpperCase()}</Text>
          {ETAPES.map((etape, i) => {
            const done = i <= etapeIndex;
            const meta = STATUTS[etape.key];
            return (
              <View key={etape.key} style={styles.timelineRow}>
                <View style={styles.timelineLeft}>
                  <View style={[
                    styles.timelineDot,
                    { backgroundColor: done ? meta.color : colors.card2, borderColor: done ? meta.color : colors.border },
                  ]}>
                    {done && <Feather name="check" size={11} color="#FFFFFF" />}
                  </View>
                  {i < ETAPES.length - 1 && (
                    <View style={[styles.timelineLine, { backgroundColor: i < etapeIndex ? '#22A06B' : colors.border }]} />
                  )}
                </View>
                <View style={styles.timelineBody}>
                  <Text style={[styles.timelineLabel, { color: done ? colors.text : colors.muted }]}>{etape.label}</Text>
                  <Text style={[styles.timelineDesc, { color: colors.muted }]}>{etape.desc}</Text>
                  <Text style={[styles.timelineDate, { color: colors.muted }]}>{etape.date}</Text>
                </View>
              </View>
            );
          })}
        </View>

        {/* DOCUMENTS JOINTS — données réelles */}
        <View style={[styles.sectionCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Text style={[styles.sectionTitle, { color: colors.muted }]}>
            {t.documentsjoints.toUpperCase()} ({demande.documents_joints?.length || 0})
          </Text>
          {demande.documents_joints?.map((doc) => (
            <View key={doc.id} style={[styles.docCard, { backgroundColor: colors.card2 }]}>
              <View style={[styles.docIcon, { backgroundColor: 'rgba(196,58,47,0.13)' }]}>
                <Feather name="file-text" size={16} color={colors.redInk} />
              </View>
              <View style={{ flex: 1, minWidth: 0 }}>
                <Text style={[styles.docName, { color: colors.text }]} numberOfLines={1}>{doc.nom_original}</Text>
                <Text style={[styles.docType, { color: colors.muted }]}>{doc.document_requis?.libelle}</Text>
              </View>
              <Feather name="check-circle" size={16} color={colors.greenInk} />
            </View>
          ))}
        </View>

        <View style={{ height: 30 }} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingHorizontal: 22, paddingTop: 56, paddingBottom: 14 },
  backBtn: { width: 38, height: 38, borderRadius: 13, alignItems: 'center', justifyContent: 'center', borderWidth: 1 },
  headerTitle: { fontSize: 20, fontWeight: '800', letterSpacing: -0.4 },
  headerSub: { fontSize: 11.5, marginTop: 1 },
  statusPill: { paddingHorizontal: 12, paddingVertical: 5, borderRadius: 999 },
  statusPillText: { fontSize: 10.5, fontWeight: '700' },
  content: { padding: 22, gap: 16 },
  typeCard: { borderRadius: 20, padding: 18 },
  typeLabel: { fontSize: 10, fontWeight: '700', letterSpacing: 1, marginBottom: 4 },
  typeVal: { fontSize: 18, fontWeight: '800' },
  typeMeta: { flexDirection: 'row', gap: 16, marginTop: 10 },
  typeMetaItem: { flexDirection: 'row', alignItems: 'center', gap: 5 },
  typeMetaText: { fontSize: 11 },
  sectionCard: { borderRadius: 20, padding: 18, borderWidth: 1 },
  sectionTitle: { fontSize: 10, fontWeight: '700', letterSpacing: 1, marginBottom: 14 },
  timelineRow: { flexDirection: 'row', gap: 13 },
  timelineLeft: { alignItems: 'center', width: 26 },
  timelineDot: { width: 24, height: 24, borderRadius: 12, borderWidth: 2, alignItems: 'center', justifyContent: 'center' },
  timelineLine: { width: 2, flex: 1, minHeight: 24, marginVertical: 3, borderRadius: 1 },
  timelineBody: { flex: 1, paddingBottom: 14 },
  timelineLabel: { fontSize: 13, fontWeight: '700' },
  timelineDesc: { fontSize: 11, marginTop: 2, lineHeight: 16 },
  timelineDate: { fontSize: 10.5, fontWeight: '600', marginTop: 3 },
  docCard: { borderRadius: 12, padding: 12, flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 7 },
  docIcon: { width: 32, height: 32, borderRadius: 9, alignItems: 'center', justifyContent: 'center' },
  docName: { fontSize: 12.5, fontWeight: '600' },
  docType: { fontSize: 10.5, marginTop: 1 },
});
