import React, { useState } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity,
  ScrollView, Alert, ActivityIndicator
} from 'react-native';
import { Feather } from '@expo/vector-icons';
import * as DocumentPicker from 'expo-document-picker';
import { useSettings } from '../../context/SettingsContext';
import api from '../../services/api';

// v2 — Étape 2/2 : 2 segments rouges, carte « type sélectionné » sur panneau vert,
// documents à joindre : bouton « Joindre » rouge → « Joint » vert + ligne fichier,
// bouton submit désactivé tant que les obligatoires manquent + note or.
// Logique conservée : DocumentPicker + FormData POST /etudiant/demandes.

export default function NouvelleDemandeScreen({ route, navigation }) {
  const { type } = route.params;
  const { colors, t, langue } = useSettings();
  const fr = langue === 'fr';
  const [fichiers, setFichiers] = useState({});
  const [loading, setLoading] = useState(false);

  const pickDocument = async (docRequis) => {
    try {
      const result = await DocumentPicker.getDocumentAsync({
        type: ['application/pdf', 'image/jpeg', 'image/png'],
        copyToCacheDirectory: true,
      });
      if (!result.canceled && result.assets?.[0]) {
        const asset = result.assets[0];
        setFichiers(prev => ({
          ...prev,
          [docRequis.id]: { uri: asset.uri, name: asset.name, mimeType: asset.mimeType || 'application/pdf', document_requis_id: docRequis.id }
        }));
      }
    } catch (e) {
      Alert.alert('Erreur', fr ? 'Impossible de sélectionner le fichier.' : 'Cannot select file.');
    }
  };

  const removeDocument = (docId) => {
    setFichiers(prev => {
      const next = { ...prev };
      delete next[docId];
      return next;
    });
  };

  const handleSubmit = async () => {
    const manquants = type.documents_requis?.filter(doc => doc.obligatoire && !fichiers[doc.id]);
    if (manquants?.length > 0) {
      Alert.alert(
        fr ? 'Documents manquants' : 'Missing documents',
        manquants.map(d => d.libelle).join(', ')
      );
      return;
    }
    setLoading(true);
    try {
      const formData = new FormData();
      formData.append('type_demande_id', type.id);
      Object.values(fichiers).forEach((fichier, index) => {
        formData.append(`documents[${index}][document_requis_id]`, fichier.document_requis_id);
        formData.append(`documents[${index}][fichier]`, { uri: fichier.uri, name: fichier.name, type: fichier.mimeType });
      });
      await api.post('/etudiant/demandes', formData, { headers: { 'Content-Type': 'multipart/form-data' } });
      Alert.alert(
        fr ? '✅ Demande envoyée !' : '✅ Request sent!',
        fr ? 'Votre demande a été soumise avec succès.' : 'Your request has been submitted successfully.',
        [{ text: 'OK', onPress: () => navigation.goBack() }]
      );
    } catch (e) {
      Alert.alert('Erreur', e?.response?.data?.message || (fr ? 'Envoi impossible.' : 'Cannot submit.'));
    } finally { setLoading(false); }
  };

  const tousObligatoiresFournis = type.documents_requis?.filter(d => d.obligatoire).every(d => fichiers[d.id]);

  return (
    <View style={[S.root, { backgroundColor: colors.bg }]}>
      {/* HEADER */}
      <View style={S.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}
          style={[S.backBtn, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Feather name="chevron-left" size={20} color={colors.text} />
        </TouchableOpacity>
        <View style={{ flex: 1 }}>
          <Text style={[S.headerTitle, { color: colors.text }]}>{t.documentsrequis}</Text>
          <Text style={[S.headerSub, { color: colors.muted }]}>
            {fr ? 'Étape 2 sur 2 — Joignez vos pièces' : 'Step 2 of 2 — Attach your documents'}
          </Text>
        </View>
      </View>

      {/* PROGRESSION — 2 segments rouges */}
      <View style={S.stepsRow}>
        <View style={[S.stepSeg, { backgroundColor: '#C43A2F' }]} />
        <View style={[S.stepSeg, { backgroundColor: '#C43A2F' }]} />
      </View>

      <ScrollView contentContainerStyle={S.content} showsVerticalScrollIndicator={false}>
        {/* TYPE SÉLECTIONNÉ — panneau vert */}
        <View style={[S.typeCard, { backgroundColor: colors.panel }]}>
          <Text style={[S.typeCardLabel, { color: colors.panelMuted }]}>
            {fr ? 'TYPE SÉLECTIONNÉ' : 'SELECTED TYPE'}
          </Text>
          <Text style={[S.typeCardVal, { color: colors.panelInk }]}>{type.libelle}</Text>
          {type.description ? (
            <Text style={[S.typeCardDesc, { color: colors.panelMuted }]}>{type.description}</Text>
          ) : null}
        </View>

        {/* DOCUMENTS — Joindre / Joint */}
        {type.documents_requis?.map((doc) => {
          const fichier = fichiers[doc.id];
          return (
            <View
              key={doc.id}
              style={[S.docCard, {
                backgroundColor: colors.card,
                borderColor: fichier ? 'rgba(34,160,107,0.45)' : colors.border,
              }]}>
              <View style={S.docTop}>
                <View style={{ flex: 1, minWidth: 0 }}>
                  <Text style={[S.docLabel, { color: colors.text }]}>{doc.libelle}</Text>
                  <Text style={[S.docOblig, { color: doc.obligatoire ? colors.gold : colors.blue }]}>
                    {doc.obligatoire ? (fr ? 'Obligatoire' : 'Required') : (fr ? 'Facultatif' : 'Optional')}
                  </Text>
                </View>
                {!fichier ? (
                  <TouchableOpacity onPress={() => pickDocument(doc)} style={S.btnAttach} activeOpacity={0.8}>
                    <Feather name="paperclip" size={12} color={colors.redInk} />
                    <Text style={[S.btnAttachText, { color: colors.redInk }]}>{fr ? 'Joindre' : 'Attach'}</Text>
                  </TouchableOpacity>
                ) : (
                  <TouchableOpacity onPress={() => removeDocument(doc.id)} style={S.btnAttached} activeOpacity={0.8}>
                    <Feather name="check" size={12} color={colors.greenInk} />
                    <Text style={[S.btnAttachedText, { color: colors.greenInk }]}>{fr ? 'Joint' : 'Attached'}</Text>
                  </TouchableOpacity>
                )}
              </View>
              {fichier && (
                <View style={[S.fileRow, { backgroundColor: colors.card2 }]}>
                  <Feather name="file-text" size={13} color={colors.greenInk} />
                  <Text style={[S.fileName, { color: colors.muted }]} numberOfLines={1}>{fichier.name}</Text>
                </View>
              )}
            </View>
          );
        })}

        {/* SOUMETTRE */}
        <TouchableOpacity
          style={[S.btnSubmit, {
            backgroundColor: tousObligatoiresFournis ? '#C43A2F' : colors.card2,
          }]}
          onPress={handleSubmit}
          disabled={loading || !tousObligatoiresFournis}
          activeOpacity={0.85}>
          {loading
            ? <ActivityIndicator color="#fff" />
            : <Text style={[S.btnSubmitText, { color: tousObligatoiresFournis ? '#FFFFFF' : colors.muted }]}>
                {t.soumettredemande}
              </Text>}
        </TouchableOpacity>

        {!tousObligatoiresFournis && (
          <View style={S.warnRow}>
            <Feather name="alert-circle" size={12} color={colors.gold} />
            <Text style={[S.warnText, { color: colors.gold }]}>
              {fr ? 'Joignez tous les documents obligatoires pour continuer' : 'Attach all required documents to continue'}
            </Text>
          </View>
        )}

        <View style={{ height: 40 }} />
      </ScrollView>
    </View>
  );
}

const S = StyleSheet.create({
  root: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingHorizontal: 22, paddingTop: 56, paddingBottom: 14 },
  backBtn: { width: 38, height: 38, borderRadius: 13, alignItems: 'center', justifyContent: 'center', borderWidth: 1 },
  headerTitle: { fontSize: 20, fontWeight: '800', letterSpacing: -0.4 },
  headerSub: { fontSize: 11.5, marginTop: 1 },
  stepsRow: { flexDirection: 'row', gap: 5, paddingHorizontal: 22, marginBottom: 18 },
  stepSeg: { flex: 1, height: 4, borderRadius: 2 },
  content: { paddingHorizontal: 22, gap: 9 },
  typeCard: { borderRadius: 18, padding: 16, marginBottom: 7 },
  typeCardLabel: { fontSize: 10, fontWeight: '700', letterSpacing: 1, marginBottom: 4 },
  typeCardVal: { fontSize: 17, fontWeight: '800' },
  typeCardDesc: { fontSize: 11.5, lineHeight: 17, marginTop: 3 },
  docCard: { borderRadius: 16, padding: 14, borderWidth: 1.5 },
  docTop: { flexDirection: 'row', alignItems: 'center', gap: 11 },
  docLabel: { fontSize: 13, fontWeight: '700' },
  docOblig: { fontSize: 9.5, fontWeight: '700', marginTop: 3 },
  btnAttach: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    backgroundColor: 'rgba(196,58,47,0.10)', borderWidth: 1, borderColor: 'rgba(196,58,47,0.30)',
    borderRadius: 10, paddingHorizontal: 13, paddingVertical: 8, flexShrink: 0,
  },
  btnAttachText: { fontSize: 11.5, fontWeight: '700' },
  btnAttached: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    backgroundColor: 'rgba(34,160,107,0.12)', borderWidth: 1, borderColor: 'rgba(34,160,107,0.32)',
    borderRadius: 10, paddingHorizontal: 13, paddingVertical: 8, flexShrink: 0,
  },
  btnAttachedText: { fontSize: 11.5, fontWeight: '700' },
  fileRow: { flexDirection: 'row', alignItems: 'center', gap: 8, borderRadius: 10, paddingHorizontal: 11, paddingVertical: 8, marginTop: 10 },
  fileName: { fontSize: 11, flex: 1 },
  btnSubmit: { borderRadius: 16, padding: 17, alignItems: 'center', marginTop: 9 },
  btnSubmitText: { fontSize: 15, fontWeight: '800' },
  warnRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 7, marginTop: 10 },
  warnText: { fontSize: 11, fontWeight: '600' },
});
