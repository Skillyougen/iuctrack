import React, { useState, useCallback } from 'react';
import {
  View, Text, StyleSheet, FlatList, TouchableOpacity,
  TextInput, ActivityIndicator, Image, RefreshControl, Modal,
  KeyboardAvoidingView, Platform
} from 'react-native';
import { Feather } from '@expo/vector-icons';
import { useFocusEffect } from '@react-navigation/native';
import { useSettings } from '../../context/SettingsContext';
import { useAuth } from '../../context/AuthContext';
import { dechiffrer } from '../../services/crypto';
import api from '../../services/api';

const BASE_URL = 'http://192.168.137.1:8000/storage/';

function decodeUTF8(str) {
  try { return decodeURIComponent(escape(str)); }
  catch { return str; }
}

// v2 — Messagerie : titre + sous-titre, carte IUCBot (bordure or) au-dessus,
// conversations en cartes arrondies, bouton crayon rouge, modal « Nouveau message » v2.
// Logique conservée : conversations réelles, déchiffrement, ouverture par matricule.

export default function MessagerieListScreen({ navigation }) {
  const { colors, langue } = useSettings();
  const fr = langue === 'fr';
  const { etudiant } = useAuth();
  const [conversations, setConversations] = useState([]);
  const [loading, setLoading]             = useState(true);
  const [refreshing, setRefreshing]       = useState(false);
  const [showNew, setShowNew]             = useState(false);
  const [matricule, setMatricule]         = useState('');
  const [searching, setSearching]         = useState(false);
  const [searchError, setSearchError]     = useState('');
  const [search, setSearch]               = useState('');

  useFocusEffect(useCallback(() => { fetchConversations(); }, []));

  const fetchConversations = async () => {
    try {
      const res = await api.get('/etudiant/messagerie/conversations');
      setConversations(res.data);
    } catch (e) { /* silencieux */ }
    finally { setLoading(false); setRefreshing(false); }
  };

  const fermerModal = () => {
    setShowNew(false);
    setMatricule('');
    setSearchError('');
  };

  const ouvrirNouvelle = async () => {
    if (!matricule.trim()) return;
    setSearching(true); setSearchError('');
    try {
      const res = await api.post('/etudiant/messagerie/ouvrir', { matricule: matricule.trim() });
      fermerModal();
      navigation.navigate('Conversation', {
        convId: res.data.conversation_id,
        autreEtudiant: res.data.autre_etudiant,
      });
    } catch (e) {
      setSearchError(e?.response?.data?.message || (fr ? 'Étudiant introuvable.' : 'Student not found.'));
    } finally { setSearching(false); }
  };

  const getDernierMsg = (conv) => {
    if (!conv.dernier_message) return fr ? 'Nouvelle conversation' : 'New conversation';
    try {
      if (conv.dernier_message.type === 'image') return '📷 Image';
      if (conv.dernier_message.type === 'sticker') return '😊 Sticker';
      const txt = decodeUTF8(dechiffrer(conv.dernier_message.contenu_chiffre, conv.dernier_message.iv));
      return txt.length > 40 ? txt.substring(0, 40) + '...' : txt;
    } catch { return '...'; }
  };

  const formatTime = (dateStr) => {
    if (!dateStr) return '';
    const d = new Date(dateStr);
    const now = new Date();
    const diff = now - d;
    if (diff < 86400000) return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    if (diff < 604800000) return ['Dim', 'Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam'][d.getDay()];
    return d.toLocaleDateString();
  };

  const filtered = conversations.filter(c => {
    if (!search.trim()) return true;
    const autre = c.autre_etudiant;
    return `${autre?.nom} ${autre?.prenom}`.toLowerCase().includes(search.toLowerCase());
  });

  const AVATAR_COLORS = ['#22A06B', '#6B8FCB', '#C43A2F', '#E9A84C'];

  const renderConv = ({ item, index }) => {
    const autre = item.autre_etudiant;
    const hasPhoto = autre?.photo;
    const initiales = `${autre?.nom?.charAt(0) || ''}${autre?.prenom?.charAt(0) || ''}`;
    return (
      <TouchableOpacity
        style={[S.convCard, { backgroundColor: colors.card, borderColor: colors.border }]}
        onPress={() => navigation.navigate('Conversation', { convId: item.id, autreEtudiant: autre })}
        activeOpacity={0.8}>
        {hasPhoto ? (
          <Image source={{ uri: BASE_URL + autre.photo }} style={S.avatarImg} />
        ) : (
          <View style={[S.avatarFallback, { backgroundColor: AVATAR_COLORS[index % AVATAR_COLORS.length] }]}>
            <Text style={S.avatarTxt}>{initiales}</Text>
          </View>
        )}
        <View style={{ flex: 1, minWidth: 0 }}>
          <Text style={[S.convNom, { color: colors.text }]} numberOfLines={1}>
            {autre?.prenom} {autre?.nom}
          </Text>
          <Text style={[S.convLastMsg, { color: item.non_lus > 0 ? colors.text : colors.muted }]} numberOfLines={1}>
            {getDernierMsg(item)}
          </Text>
        </View>
        <View style={S.convRight}>
          <Text style={[S.convTime, { color: colors.muted }]}>{formatTime(item.updated_at)}</Text>
          {item.non_lus > 0 && (
            <View style={S.badgeWrap}>
              <Text style={S.badgeTxt}>{item.non_lus}</Text>
            </View>
          )}
        </View>
      </TouchableOpacity>
    );
  };

  return (
    <View style={[S.root, { backgroundColor: colors.bg }]}>
      {/* HEADER */}
      <View style={S.header}>
        <View>
          <Text style={[S.headerTitle, { color: colors.text }]}>{fr ? 'Messagerie' : 'Messages'}</Text>
          <Text style={[S.headerSub, { color: colors.muted }]}>
            {fr ? 'Échangez avec les étudiants' : 'Chat with students'}
          </Text>
        </View>
        <TouchableOpacity onPress={() => setShowNew(true)} style={S.fab} activeOpacity={0.85}>
          <Feather name="edit-2" size={16} color="#fff" />
        </TouchableOpacity>
      </View>

      {/* RECHERCHE */}
      <View style={[S.searchBar, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <Feather name="search" size={14} color={colors.muted} />
        <TextInput
          style={[S.searchInput, { color: colors.text }]}
          placeholder={fr ? 'Rechercher…' : 'Search…'}
          placeholderTextColor={colors.muted}
          value={search}
          onChangeText={setSearch}
        />
      </View>

      {/* IUCBOT — accès rapide */}
      <TouchableOpacity
        style={[S.botCard, { backgroundColor: colors.card }]}
        onPress={() => navigation.navigate('Chat')}
        activeOpacity={0.85}>
        <View style={S.botIcon}>
          <Feather name="cpu" size={19} color={colors.gold} />
        </View>
        <View style={{ flex: 1 }}>
          <Text style={[S.botTitle, { color: colors.text }]}>IUCBot</Text>
          <Text style={[S.botSub, { color: colors.muted }]}>
            {fr ? 'Assistant IA — réponse immédiate' : 'AI assistant — instant answers'}
          </Text>
        </View>
        <View style={[S.botChip, { borderColor: colors.gold }]}>
          <Text style={[S.botChipText, { color: colors.gold }]}>IA</Text>
        </View>
      </TouchableOpacity>

      {loading ? (
        <View style={S.centered}>
          <ActivityIndicator size="large" color="#C43A2F" />
        </View>
      ) : filtered.length === 0 ? (
        <View style={S.centered}>
          <View style={[S.emptyIcon, { backgroundColor: colors.card }]}>
            <Feather name="message-circle" size={34} color={colors.muted} />
          </View>
          <Text style={[S.emptyTitle, { color: colors.text }]}>
            {fr ? 'Aucune conversation' : 'No conversations'}
          </Text>
          <Text style={[S.emptySub, { color: colors.muted }]}>
            {fr ? 'Appuyez sur le crayon pour démarrer une discussion' : 'Tap the pencil icon to start a chat'}
          </Text>
          <TouchableOpacity onPress={() => setShowNew(true)} style={S.newBtn} activeOpacity={0.85}>
            <Text style={S.newBtnTxt}>{fr ? 'Nouveau message' : 'New message'}</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <FlatList
          data={filtered}
          keyExtractor={i => i.id.toString()}
          renderItem={renderConv}
          contentContainerStyle={S.listContent}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={() => { setRefreshing(true); fetchConversations(); }}
              tintColor="#C43A2F"
            />
          }
        />
      )}

      {/* MODAL NOUVEAU MESSAGE */}
      <Modal visible={showNew} transparent animationType="slide" onRequestClose={fermerModal}>
        <TouchableOpacity style={S.modalOverlay} activeOpacity={1} onPress={fermerModal}>
          <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
            <TouchableOpacity activeOpacity={1} style={[S.modalBox, { backgroundColor: colors.card }]}>
              <View style={S.modalHeader}>
                <Text style={[S.modalTitle, { color: colors.text }]}>
                  {fr ? 'Nouveau message' : 'New message'}
                </Text>
                <TouchableOpacity onPress={fermerModal}>
                  <Feather name="x" size={20} color={colors.muted} />
                </TouchableOpacity>
              </View>
              <Text style={[S.modalLabel, { color: colors.muted }]}>
                {fr ? "Matricule de l'étudiant" : 'Student ID'}
              </Text>
              <TextInput
                style={[S.modalInput, { backgroundColor: colors.input, color: colors.text, borderColor: colors.border }]}
                placeholder="IUC2024-XXXX"
                placeholderTextColor={colors.muted}
                value={matricule}
                onChangeText={setMatricule}
                autoCapitalize="characters"
              />
              {searchError ? <Text style={[S.errorTxt, { color: colors.redInk }]}>{searchError}</Text> : null}
              <TouchableOpacity
                onPress={ouvrirNouvelle}
                disabled={searching || !matricule.trim()}
                style={[S.modalBtn, { opacity: !matricule.trim() ? 0.5 : 1 }]}
                activeOpacity={0.85}>
                {searching
                  ? <ActivityIndicator color="#fff" size="small" />
                  : <Text style={S.modalBtnTxt}>{fr ? 'Démarrer' : 'Start'}</Text>}
              </TouchableOpacity>
            </TouchableOpacity>
          </KeyboardAvoidingView>
        </TouchableOpacity>
      </Modal>
    </View>
  );
}

const S = StyleSheet.create({
  root: { flex: 1 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-end', paddingHorizontal: 22, paddingTop: 56, paddingBottom: 14 },
  headerTitle: { fontSize: 26, fontWeight: '800', letterSpacing: -0.5 },
  headerSub: { fontSize: 11.5, marginTop: 2 },
  fab: {
    width: 42, height: 42, borderRadius: 14, backgroundColor: '#C43A2F',
    alignItems: 'center', justifyContent: 'center',
    shadowColor: '#C43A2F', shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.35, shadowRadius: 14, elevation: 7,
  },
  searchBar: {
    flexDirection: 'row', alignItems: 'center', gap: 9,
    marginHorizontal: 22, marginBottom: 12,
    borderRadius: 14, borderWidth: 1, paddingHorizontal: 14, paddingVertical: 11,
  },
  searchInput: { flex: 1, fontSize: 13 },
  botCard: {
    flexDirection: 'row', alignItems: 'center', gap: 12,
    marginHorizontal: 22, marginBottom: 12,
    borderRadius: 18, borderWidth: 1.5, borderColor: '#E9A84C', padding: 14,
  },
  botIcon: {
    width: 44, height: 44, borderRadius: 22,
    backgroundColor: 'rgba(233,168,76,0.16)', alignItems: 'center', justifyContent: 'center',
  },
  botTitle: { fontSize: 13.5, fontWeight: '800' },
  botSub: { fontSize: 11, marginTop: 1 },
  botChip: { borderWidth: 1, borderRadius: 999, paddingHorizontal: 9, paddingVertical: 3 },
  botChipText: { fontSize: 9.5, fontWeight: '800' },
  centered: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 32, gap: 12 },
  emptyIcon: { width: 76, height: 76, borderRadius: 38, alignItems: 'center', justifyContent: 'center', marginBottom: 6 },
  emptyTitle: { fontSize: 17, fontWeight: '800' },
  emptySub: { fontSize: 12.5, textAlign: 'center', lineHeight: 19 },
  newBtn: { backgroundColor: '#C43A2F', borderRadius: 14, paddingHorizontal: 24, paddingVertical: 13, marginTop: 6 },
  newBtnTxt: { color: '#fff', fontSize: 13.5, fontWeight: '700' },
  listContent: { paddingHorizontal: 22, gap: 9, paddingBottom: 120 },
  convCard: {
    flexDirection: 'row', alignItems: 'center', gap: 12,
    borderRadius: 18, borderWidth: 1, padding: 14,
  },
  avatarImg: { width: 44, height: 44, borderRadius: 22 },
  avatarFallback: { width: 44, height: 44, borderRadius: 22, alignItems: 'center', justifyContent: 'center' },
  avatarTxt: { color: '#fff', fontSize: 13, fontWeight: '800' },
  convNom: { fontSize: 13.5, fontWeight: '700' },
  convLastMsg: { fontSize: 11, marginTop: 2 },
  convRight: { alignItems: 'flex-end', gap: 5, flexShrink: 0 },
  convTime: { fontSize: 10 },
  badgeWrap: { backgroundColor: '#C43A2F', borderRadius: 10, minWidth: 18, height: 18, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 5 },
  badgeTxt: { color: '#fff', fontSize: 10, fontWeight: '800' },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
  modalBox: { borderTopLeftRadius: 26, borderTopRightRadius: 26, padding: 24, gap: 14 },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  modalTitle: { fontSize: 18, fontWeight: '800' },
  modalLabel: { fontSize: 11.5, fontWeight: '600' },
  modalInput: { borderRadius: 14, borderWidth: 1, padding: 15, fontSize: 14.5 },
  errorTxt: { fontSize: 12 },
  modalBtn: { backgroundColor: '#C43A2F', borderRadius: 15, padding: 15, alignItems: 'center' },
  modalBtnTxt: { color: '#fff', fontSize: 14.5, fontWeight: '700' },
});
