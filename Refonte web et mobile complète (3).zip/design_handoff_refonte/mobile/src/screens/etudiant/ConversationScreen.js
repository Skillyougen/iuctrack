import React, { useState, useEffect, useRef } from 'react';
import {
  View, Text, StyleSheet, FlatList, TextInput, TouchableOpacity,
  KeyboardAvoidingView, Platform, Image, ActivityIndicator,
  SafeAreaView, ScrollView, Modal
} from 'react-native';
import { Feather } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import { useSettings } from '../../context/SettingsContext';
import { useAuth } from '../../context/AuthContext';
import { chiffrer, dechiffrer } from '../../services/crypto';
import api from '../../services/api';

const BASE_URL = 'http://192.168.137.1:8000/storage/';

const STICKERS = ['😊','😂','❤️','👍','🙏','😢','🔥','🎉','👏','😍','🤔','😎','💪','✅','🙌','😅','🥰','😭','👀','💯'];

function encodeUTF8(str) {
  try { return unescape(encodeURIComponent(str)); } catch { return str; }
}
function decodeUTF8(str) {
  try { return decodeURIComponent(escape(str)); } catch { return str; }
}

// v2 — Conversation : header avec bouton retour arrondi + statut « En ligne » vert,
// bulles arrondies 16/5 (rouge #C43A2F pour soi, carte pour l'autre), barre d'envoi
// en pilule + bouton rond rouge. Logique conservée : chiffrement, polling 3s,
// stickers, envoi image (aperçu + fallback base64), coches lu/livré, visionneuse.

export default function ConversationScreen({ route, navigation }) {
  const { convId, autreEtudiant } = route.params;
  const { colors, langue } = useSettings();
  const fr = langue === 'fr';
  const { etudiant } = useAuth();
  const [messages, setMessages]         = useState([]);
  const [loading, setLoading]           = useState(true);
  const [input, setInput]               = useState('');
  const [sending, setSending]           = useState(false);
  const [showStickers, setShowStickers] = useState(false);
  const [previewImage, setPreviewImage] = useState(null);
  const [viewerImage, setViewerImage]   = useState(null);

  const flatListRef = useRef(null);
  const pollRef     = useRef(null);

  useEffect(() => {
    fetchMessages();
    pollRef.current = setInterval(fetchMessages, 3000);
    return () => clearInterval(pollRef.current);
  }, []);

  const fetchMessages = async () => {
    try {
      const res = await api.get(`/etudiant/messagerie/${convId}/messages`);
      const decrypted = res.data.map(msg => ({
        ...msg,
        texte: msg.type !== 'image' ? decodeUTF8(dechiffrer(msg.contenu_chiffre, msg.iv)) : null,
      }));
      setMessages(decrypted);
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  };

  const envoyer = async (type = 'texte', contenu = null) => {
    const texte = contenu || input.trim();
    if (!texte && type === 'texte') return;
    setSending(true);
    try {
      const texteEncode = encodeUTF8(texte);
      const { contenu_chiffre, iv } = await chiffrer(texteEncode);
      await api.post(`/etudiant/messagerie/${convId}/envoyer`, { type, contenu_chiffre, iv });
      setInput('');
      setShowStickers(false);
      await fetchMessages();
      setTimeout(() => flatListRef.current?.scrollToEnd({ animated: true }), 100);
    } catch (e) { console.error(e); }
    finally { setSending(false); }
  };

  const choisirImage = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ['images'],
      quality: 0.7,
      base64: true,
    });
    if (result.canceled) return;
    setPreviewImage(result.assets[0]);
  };

  const annulerPreview = () => setPreviewImage(null);

  const confirmerEnvoiImage = async () => {
    if (!previewImage) return;
    const asset = previewImage;
    setPreviewImage(null);
    setSending(true);
    try {
      const { contenu_chiffre, iv } = await chiffrer('image');
      const formData = new FormData();
      formData.append('image', { uri: asset.uri, name: 'photo.jpg', type: asset.mimeType || 'image/jpeg' });
      formData.append('contenu_chiffre', contenu_chiffre);
      formData.append('iv', iv);
      try {
        await api.post(`/etudiant/messagerie/${convId}/envoyer-image`, formData, {
          headers: { 'Content-Type': 'multipart/form-data' },
          timeout: 30000,
        });
      } catch {
        await api.post(`/etudiant/messagerie/${convId}/envoyer-image`, {
          image_base64: `data:image/jpeg;base64,${asset.base64}`,
          contenu_chiffre, iv,
        });
      }
      await fetchMessages();
      setTimeout(() => flatListRef.current?.scrollToEnd({ animated: true }), 100);
    } catch (e) {
      console.error('Erreur image:', e?.response?.data || e.message);
    }
    finally { setSending(false); }
  };

  const isMine = (msg) => msg.expediteur_id === etudiant?.id;

  const formatTime = (dateStr) =>
    new Date(dateStr).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  const renderChecks = (item) => {
    if (item.lu) {
      return (
        <View style={S.checkWrap}>
          <Feather name="check" size={12} color="#8FD8FF" style={{ marginRight: -6 }} />
          <Feather name="check" size={12} color="#8FD8FF" />
        </View>
      );
    }
    if (item.livre !== false) {
      return (
        <View style={S.checkWrap}>
          <Feather name="check" size={12} color="rgba(255,255,255,0.6)" style={{ marginRight: -6 }} />
          <Feather name="check" size={12} color="rgba(255,255,255,0.6)" />
        </View>
      );
    }
    return <Feather name="check" size={12} color="rgba(255,255,255,0.6)" />;
  };

  const renderMessage = ({ item, index }) => {
    const mine = isMine(item);
    const showDate = index === 0 || new Date(item.created_at).toDateString() !== new Date(messages[index - 1]?.created_at).toDateString();

    return (
      <>
        {showDate && (
          <View style={S.dateSep}>
            <View style={[S.dateLine, { backgroundColor: colors.border }]} />
            <Text style={[S.dateText, { color: colors.muted }]}>
              {new Date(item.created_at).toLocaleDateString(fr ? 'fr-FR' : 'en-US', { weekday: 'long', day: 'numeric', month: 'long' })}
            </Text>
            <View style={[S.dateLine, { backgroundColor: colors.border }]} />
          </View>
        )}
        <View style={[S.msgRow, mine ? S.msgRowRight : S.msgRowLeft]}>
          {!mine && (
            <View style={[S.msgAvatar, { backgroundColor: '#6B8FCB' }]}>
              {autreEtudiant?.photo ? (
                <Image source={{ uri: BASE_URL + autreEtudiant.photo }} style={S.msgAvatarImg} />
              ) : (
                <Text style={S.msgAvatarTxt}>{autreEtudiant?.nom?.charAt(0)}</Text>
              )}
            </View>
          )}
          <View style={[
            S.bubble,
            mine
              ? S.bubbleMine
              : [S.bubbleTheirs, { backgroundColor: colors.card, borderColor: colors.border }],
          ]}>
            {item.type === 'image' && item.image_path ? (
              <TouchableOpacity onPress={() => setViewerImage(BASE_URL + item.image_path)}>
                <Image source={{ uri: BASE_URL + item.image_path }} style={S.bubbleImage} resizeMode="cover" />
              </TouchableOpacity>
            ) : item.type === 'sticker' ? (
              <Text style={S.stickerText}>{item.texte}</Text>
            ) : (
              <Text style={[S.bubbleTxt, { color: mine ? '#fff' : colors.text }]}>{item.texte}</Text>
            )}
            <View style={S.bubbleFooter}>
              <Text style={[S.bubbleTime, { color: mine ? 'rgba(255,255,255,0.65)' : colors.muted }]}>
                {formatTime(item.created_at)}
              </Text>
              {mine && renderChecks(item)}
            </View>
          </View>
        </View>
      </>
    );
  };

  return (
    <SafeAreaView style={[S.root, { backgroundColor: colors.bg }]}>
      {/* HEADER */}
      <View style={[S.header, { borderBottomColor: colors.border }]}>
        <TouchableOpacity
          onPress={() => navigation.goBack()}
          style={[S.backBtn, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Feather name="chevron-left" size={18} color={colors.text} />
        </TouchableOpacity>
        {autreEtudiant?.photo ? (
          <Image source={{ uri: BASE_URL + autreEtudiant.photo }} style={S.headerAvatar} />
        ) : (
          <View style={[S.headerAvatarFallback, { backgroundColor: '#22A06B' }]}>
            <Text style={S.headerAvatarTxt}>
              {autreEtudiant?.nom?.charAt(0)}{autreEtudiant?.prenom?.charAt(0)}
            </Text>
          </View>
        )}
        <View style={{ flex: 1, minWidth: 0 }}>
          <Text style={[S.headerName, { color: colors.text }]} numberOfLines={1}>
            {autreEtudiant?.prenom} {autreEtudiant?.nom}
          </Text>
          <View style={S.onlineRow}>
            <View style={S.onlineDot} />
            <Text style={[S.onlineText, { color: colors.greenInk }]}>
              {fr ? 'En ligne' : 'Online'}
            </Text>
          </View>
        </View>
      </View>

      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : 20}>
        {loading ? (
          <View style={S.centered}><ActivityIndicator size="large" color="#C43A2F" /></View>
        ) : (
          <FlatList
            ref={flatListRef}
            data={messages}
            keyExtractor={i => i.id.toString()}
            renderItem={renderMessage}
            contentContainerStyle={S.msgList}
            onContentSizeChange={() => flatListRef.current?.scrollToEnd({ animated: false })}
            showsVerticalScrollIndicator={false}
          />
        )}

        {showStickers && (
          <View style={[S.stickersPanel, { backgroundColor: colors.card, borderTopColor: colors.border }]}>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={S.stickersList}>
              {STICKERS.map((s, i) => (
                <TouchableOpacity key={i} onPress={() => envoyer('sticker', s)} style={S.stickerBtn}>
                  <Text style={{ fontSize: 30 }}>{s}</Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
          </View>
        )}

        {/* BARRE D'ENVOI */}
        <View style={[S.inputBar, { backgroundColor: colors.bg, borderTopColor: colors.border }]}>
          <TouchableOpacity
            onPress={() => setShowStickers(!showStickers)}
            style={[S.inputAction, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Text style={{ fontSize: 18 }}>😊</Text>
          </TouchableOpacity>

          <TextInput
            style={[S.input, { backgroundColor: colors.input, color: colors.text, borderColor: colors.border }]}
            placeholder={fr ? 'Votre message…' : 'Your message…'}
            placeholderTextColor={colors.muted}
            value={input}
            onChangeText={setInput}
            multiline
            maxLength={1000}
            onFocus={() => setShowStickers(false)}
          />

          <TouchableOpacity
            onPress={choisirImage}
            style={[S.inputAction, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Feather name="image" size={18} color={colors.muted} />
          </TouchableOpacity>

          <TouchableOpacity
            onPress={() => envoyer()}
            disabled={sending || !input.trim()}
            style={[S.sendBtn, { opacity: input.trim() && !sending ? 1 : 0.5 }]}
            activeOpacity={0.85}>
            {sending
              ? <ActivityIndicator size="small" color="#fff" />
              : <Feather name="send" size={16} color="#fff" />}
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>

      {/* MODAL APERÇU AVANT ENVOI */}
      <Modal visible={!!previewImage} transparent animationType="fade">
        <View style={S.previewOverlay}>
          <TouchableOpacity style={S.previewClose} onPress={annulerPreview}>
            <Feather name="x" size={26} color="#fff" />
          </TouchableOpacity>
          {previewImage && (
            <Image source={{ uri: previewImage.uri }} style={S.previewImg} resizeMode="contain" />
          )}
          <View style={S.previewActions}>
            <TouchableOpacity onPress={annulerPreview} style={S.previewCancelBtn}>
              <Text style={S.previewCancelTxt}>{fr ? 'Annuler' : 'Cancel'}</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={confirmerEnvoiImage} style={S.previewSendBtn}>
              <Feather name="send" size={18} color="#fff" />
              <Text style={S.previewSendTxt}>{fr ? 'Envoyer' : 'Send'}</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* MODAL VISIONNEUSE PLEIN ÉCRAN */}
      <Modal visible={!!viewerImage} transparent animationType="fade">
        <View style={S.previewOverlay}>
          <TouchableOpacity style={S.previewClose} onPress={() => setViewerImage(null)}>
            <Feather name="x" size={26} color="#fff" />
          </TouchableOpacity>
          {viewerImage && (
            <Image source={{ uri: viewerImage }} style={S.previewImg} resizeMode="contain" />
          )}
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const S = StyleSheet.create({
  root: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 20, paddingVertical: 10, gap: 11, borderBottomWidth: 1 },
  backBtn: { width: 36, height: 36, borderRadius: 12, alignItems: 'center', justifyContent: 'center', borderWidth: 1 },
  headerAvatar: { width: 40, height: 40, borderRadius: 20 },
  headerAvatarFallback: { width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center' },
  headerAvatarTxt: { color: '#fff', fontSize: 12, fontWeight: '800' },
  headerName: { fontSize: 13.5, fontWeight: '800' },
  onlineRow: { flexDirection: 'row', alignItems: 'center', gap: 5, marginTop: 1 },
  onlineDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: '#22A06B' },
  onlineText: { fontSize: 10.5 },
  centered: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  msgList: { paddingHorizontal: 16, paddingVertical: 12, gap: 4 },
  dateSep: { flexDirection: 'row', alignItems: 'center', marginVertical: 10, gap: 8 },
  dateLine: { flex: 1, height: 1 },
  dateText: { fontSize: 10.5, paddingHorizontal: 8, fontWeight: '600' },
  msgRow: { flexDirection: 'row', alignItems: 'flex-end', gap: 7, marginVertical: 2 },
  msgRowRight: { justifyContent: 'flex-end' },
  msgRowLeft: { justifyContent: 'flex-start' },
  msgAvatar: { width: 26, height: 26, borderRadius: 13, alignItems: 'center', justifyContent: 'center', flexShrink: 0, marginBottom: 2 },
  msgAvatarImg: { width: 26, height: 26, borderRadius: 13 },
  msgAvatarTxt: { color: '#fff', fontSize: 10, fontWeight: '800' },
  bubble: { maxWidth: '76%', paddingHorizontal: 13, paddingTop: 9, paddingBottom: 5, borderRadius: 16 },
  bubbleMine: { backgroundColor: '#C43A2F', borderBottomRightRadius: 5 },
  bubbleTheirs: { borderBottomLeftRadius: 5, borderWidth: 1 },
  bubbleTxt: { fontSize: 12.5, lineHeight: 19 },
  stickerText: { fontSize: 36 },
  bubbleImage: { width: 180, height: 180, borderRadius: 10 },
  bubbleFooter: { flexDirection: 'row', alignItems: 'center', justifyContent: 'flex-end', gap: 3, marginTop: 2 },
  bubbleTime: { fontSize: 9.5 },
  checkWrap: { flexDirection: 'row', alignItems: 'center' },
  stickersPanel: { borderTopWidth: 1, paddingVertical: 8 },
  stickersList: { paddingHorizontal: 12, gap: 6 },
  stickerBtn: { padding: 4 },
  inputBar: { flexDirection: 'row', alignItems: 'flex-end', paddingHorizontal: 16, paddingVertical: 10, gap: 8, borderTopWidth: 1 },
  inputAction: { width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center', borderWidth: 1 },
  input: { flex: 1, borderRadius: 22, paddingHorizontal: 15, paddingVertical: 11, fontSize: 13, borderWidth: 1, maxHeight: 100 },
  sendBtn: {
    width: 44, height: 44, borderRadius: 22, backgroundColor: '#C43A2F',
    alignItems: 'center', justifyContent: 'center', flexShrink: 0,
  },
  previewOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.92)', justifyContent: 'center', alignItems: 'center' },
  previewClose: { position: 'absolute', top: 50, right: 20, zIndex: 10, padding: 8 },
  previewImg: { width: '90%', height: '70%' },
  previewActions: { position: 'absolute', bottom: 40, flexDirection: 'row', gap: 16 },
  previewCancelBtn: { paddingHorizontal: 24, paddingVertical: 12, borderRadius: 24, backgroundColor: 'rgba(255,255,255,0.15)' },
  previewCancelTxt: { color: '#fff', fontSize: 14, fontWeight: '600' },
  previewSendBtn: { flexDirection: 'row', alignItems: 'center', gap: 8, paddingHorizontal: 24, paddingVertical: 12, borderRadius: 24, backgroundColor: '#C43A2F' },
  previewSendTxt: { color: '#fff', fontSize: 14, fontWeight: '700' },
});
