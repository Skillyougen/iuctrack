import React, { useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView,
  TouchableOpacity, Image
} from 'react-native';
import { Feather } from '@expo/vector-icons';
import { useSettings } from '../../context/SettingsContext';
import logoIcon from '../../../assets/images/logo-icon.png';
import logoHorizontal from '../../../assets/images/logo-horizontal.png';

// v2 — Découvrir l'IUC : héros sur panneau vert sombre (logo sur pastille blanche,
// pills statistiques en contour), bannière IUCBot rouge, contenu réel conservé
// (chiffres, histoire, timeline, campus, écoles dépliables, partenariats, CTA).

export default function DecouvrirIUCScreen({ navigation }) {
  const { colors, langue } = useSettings();
  const [expandedSchool, setExpandedSchool] = useState(null);
  const [expandedCampus, setExpandedCampus] = useState(null);

  const fr = langue === 'fr';
  const RED = '#C43A2F';

  const chiffres = [
    { val: '2002', label: fr ? 'Année de création' : 'Year founded' },
    { val: '24 ans', label: fr ? "D'expérience" : 'Of experience' },
    { val: '5', label: fr ? 'Campus' : 'Campuses' },
    { val: '5', label: fr ? 'Écoles' : 'Schools' },
    { val: '+12', label: fr ? 'Domaines de formation' : 'Fields of study' },
    { val: '3', label: fr ? 'Cités universitaires' : 'Student residences' },
  ];

  const campus = [
    { nom: fr ? 'Campus de Logbessou' : 'Logbessou Campus', ville: 'Douala', desc: fr ? "Campus principal et pôle d'excellence." : 'Main campus and center of excellence.', icon: 'star' },
    { nom: fr ? "Campus d'Akwa" : 'Akwa Campus', ville: 'Douala', desc: fr ? "Formations proches du monde de l'entreprise." : 'Training close to the business world.', icon: 'briefcase' },
    { nom: fr ? "Campus d'Excellence" : 'Excellence Campus', ville: 'Douala', desc: fr ? 'Programmes à forte exigence académique.' : 'Programs with high academic standards.', icon: 'award' },
    { nom: fr ? 'Campus de Denver' : 'Denver Campus', ville: 'Douala', desc: fr ? 'Formation généraliste et proximité résidentielle.' : 'General education and residential proximity.', icon: 'home' },
    { nom: fr ? 'Campus de Dschang' : 'Dschang Campus', ville: 'Dschang', desc: fr ? 'Développement régional et formations délocalisées.' : 'Regional development and decentralized programs.', icon: 'map-pin' },
  ];

  const ecoles = [
    {
      sigle: 'ISTDI',
      nom: fr ? 'Institut Supérieur des Technologies et du Design Industriel' : 'Higher Institute of Technology and Industrial Design',
      annee: 2002, color: '#C43A2F', icon: 'tool',
      domaines: fr
        ? ['Génie civil', 'Architecture', 'Génie électrique', 'Génie mécanique', 'Génie industriel', 'Énergies renouvelables', 'HSE', 'Télécommunications', 'Maintenance industrielle']
        : ['Civil Engineering', 'Architecture', 'Electrical Engineering', 'Mechanical Engineering', 'Industrial Engineering', 'Renewable Energy', 'HSE', 'Telecommunications', 'Industrial Maintenance'],
    },
    {
      sigle: '3IAC',
      nom: fr ? "Institut d'Ingénierie Informatique d'Afrique Centrale" : 'Institute of Computer Engineering of Central Africa',
      annee: 2007, color: '#22A06B', icon: 'cpu',
      domaines: fr
        ? ['Génie logiciel', 'Informatique', 'Réseaux', 'Cybersécurité', 'Intelligence artificielle', 'Télécommunications', 'Sciences informatiques']
        : ['Software Engineering', 'Computer Science', 'Networks', 'Cybersecurity', 'Artificial Intelligence', 'Telecommunications', 'Computer Sciences'],
    },
    {
      sigle: 'ICIA',
      nom: fr ? "Institut de Commerce et d'Ingénierie d'Affaires" : 'Institute of Commerce and Business Engineering',
      annee: 2011, color: '#6B8FCB', icon: 'trending-up',
      domaines: fr
        ? ['Comptabilité', 'Banque et finance', 'Marketing', 'Commerce international', 'Logistique et transport', 'GRH', 'Communication des organisations']
        : ['Accounting', 'Banking & Finance', 'Marketing', 'International Trade', 'Logistics & Transport', 'HRM', 'Organizational Communication'],
    },
    {
      sigle: fr ? 'Santé' : 'Health',
      nom: fr ? 'Écoles Santé et Sciences Appliquées' : 'Health & Applied Sciences Schools',
      annee: null, color: '#E9A84C', icon: 'heart',
      domaines: fr
        ? ['Sciences infirmières', 'Kinésithérapie', 'Biomédical', 'Analyses médicales', 'Santé publique']
        : ['Nursing Sciences', 'Physiotherapy', 'Biomedical', 'Medical Analysis', 'Public Health'],
    },
    {
      sigle: 'SEAS',
      nom: 'School of Engineering and Applied Sciences',
      annee: null, color: '#9B59B6', icon: 'layers',
      domaines: fr
        ? ['Agriculture', 'Informatique appliquée', 'Biomédical', 'Physiothérapie', "Sciences de l'ingénieur"]
        : ['Agriculture', 'Applied Computer Science', 'Biomedical', 'Physiotherapy', 'Engineering Sciences'],
    },
  ];

  const partenaires = [
    { pays: 'France', icon: '🇫🇷', desc: fr ? 'Doubles diplômes & mobilité étudiante' : 'Double degrees & student mobility' },
    { pays: 'Italie', icon: '🇮🇹', desc: fr ? 'Échanges académiques & cycles ingénieurs' : 'Academic exchanges & engineering programs' },
    { pays: 'Canada', icon: '🇨🇦', desc: fr ? 'Programmes internationaux conjoints' : 'Joint international programs' },
  ];

  const cycles = ['BTS', 'Licence', 'Bachelor', 'Master', 'Ingénieur'];

  return (
    <View style={[S.root, { backgroundColor: colors.bg }]}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={S.scroll}>

        {/* HEADER */}
        <View style={S.topBar}>
          <TouchableOpacity
            style={[S.backBtn, { backgroundColor: colors.card, borderColor: colors.border }]}
            onPress={() => navigation.goBack()}>
            <Feather name="chevron-left" size={20} color={colors.text} />
          </TouchableOpacity>
          <View>
            <Text style={[S.topTitle, { color: colors.text }]}>
              {fr ? "Découvrir l'IUC" : 'Discover IUC'}
            </Text>
            <Text style={[S.topSub, { color: colors.muted }]}>
              {fr ? 'Mode visiteur — sans compte' : 'Visitor mode — no account'}
            </Text>
          </View>
        </View>

        {/* HÉROS — panneau vert sombre */}
        <View style={{ paddingHorizontal: 22 }}>
          <View style={[S.hero, { backgroundColor: colors.panel }]}>
            <View style={S.heroLogoWrap}>
              <Image source={logoHorizontal} style={S.heroLogo} resizeMode="contain" />
            </View>
            <Text style={[S.heroTitle, { color: colors.panelInk }]}>
              Institut Universitaire de la Côte
            </Text>
            <Text style={[S.heroSub, { color: colors.panelMuted }]}>
              {fr
                ? "Pôle d'excellence académique en Afrique centrale depuis 2002 — Douala, Cameroun."
                : 'Academic center of excellence in Central Africa since 2002 — Douala, Cameroon.'}
            </Text>
            <View style={S.heroPillsRow}>
              {cycles.map((c, i) => (
                <View key={i} style={[S.heroPill, { borderColor: colors.panelInk }]}>
                  <Text style={[S.heroPillText, { color: colors.panelInk }]}>{c}</Text>
                </View>
              ))}
            </View>
          </View>
        </View>

        {/* BANNIÈRE IUCBOT */}
        <View style={{ paddingHorizontal: 22 }}>
          <TouchableOpacity onPress={() => navigation.navigate('Chat')} activeOpacity={0.85} style={S.chatBanner}>
            <View style={S.chatBannerLeft}>
              <View style={S.chatBannerIcon}>
                <Feather name="cpu" size={20} color="#fff" />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={S.chatBannerTitle}>
                  {fr ? "Des questions sur l'IUC ?" : 'Questions about IUC?'}
                </Text>
                <Text style={S.chatBannerSub}>
                  {fr ? 'IUCBot répond à toutes vos questions en temps réel' : 'IUCBot answers all your questions in real time'}
                </Text>
              </View>
            </View>
            <View style={S.chatBannerArrow}>
              <Feather name="message-circle" size={16} color="#fff" />
            </View>
          </TouchableOpacity>
        </View>

        {/* CHIFFRES CLÉS */}
        <View style={S.section}>
          <Text style={[S.sectionTitle, { color: colors.text }]}>{fr ? 'Chiffres clés' : 'Key figures'}</Text>
          <View style={S.chiffresGrid}>
            {chiffres.map((c, i) => (
              <View key={i} style={[S.chiffreCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
                <Text style={[S.chiffreVal, { color: RED }]}>{c.val}</Text>
                <Text style={[S.chiffreLabel, { color: colors.muted }]}>{c.label}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* HISTOIRE */}
        <View style={S.section}>
          <Text style={[S.sectionTitle, { color: colors.text }]}>{fr ? 'Notre histoire' : 'Our history'}</Text>
          <View style={[S.card, { backgroundColor: colors.card, borderColor: colors.border, gap: 14 }]}>
            {[
              { icon: 'user',     label: fr ? 'Fondateur' : 'Founder',  val: 'Paul Guimezap' },
              { icon: 'calendar', label: fr ? 'Création' : 'Founded',   val: fr ? '13 septembre 2002, par arrêté ministériel' : 'September 13, 2002, by ministerial decree' },
              { icon: 'target',   label: fr ? 'Vision' : 'Vision',      val: fr ? "Former des techniciens, cadres et ingénieurs adaptés aux besoins du marché africain et devenir un pôle d'excellence en Afrique." : 'Train technicians, managers and engineers adapted to the African market and become a center of excellence in Africa.' },
            ].map((item, i, arr) => (
              <View key={i}>
                <View style={S.histoireRow}>
                  <View style={[S.histoireIcon, { backgroundColor: 'rgba(196,58,47,0.12)' }]}>
                    <Feather name={item.icon} size={14} color={colors.redInk} />
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={[S.histoireLabel, { color: colors.muted }]}>{item.label}</Text>
                    <Text style={[S.histoireVal, { color: colors.text }]}>{item.val}</Text>
                  </View>
                </View>
                {i < arr.length - 1 && <View style={[S.divider, { backgroundColor: colors.border }]} />}
              </View>
            ))}
          </View>

          <View style={[S.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Text style={[S.timelineTitle, { color: colors.text }]}>
              {fr ? "Évolution de l'institution" : 'Institution evolution'}
            </Text>
            {[
              { annee: '2002', ecole: 'ISTDI', desc: fr ? "Création de l'IUC avec l'ISTDI" : 'IUC founded with ISTDI' },
              { annee: '2007', ecole: '3IAC',  desc: fr ? "Ouverture de l'école informatique" : 'Opening of the IT school' },
              { annee: '2011', ecole: 'ICIA',  desc: fr ? 'Lancement des formations en commerce' : 'Launch of business training programs' },
            ].map((item, i) => (
              <View key={i} style={S.timelineItem}>
                <View style={S.timelineLeft}>
                  <View style={[S.timelineDot, { backgroundColor: RED }]} />
                  {i < 2 && <View style={[S.timelineLine, { backgroundColor: colors.border }]} />}
                </View>
                <View style={S.timelineContent}>
                  <Text style={[S.timelineAnnee, { color: RED }]}>{item.annee}</Text>
                  <Text style={[S.timelineEcole, { color: colors.text }]}>{item.ecole}</Text>
                  <Text style={[S.timelineDesc, { color: colors.muted }]}>{item.desc}</Text>
                </View>
              </View>
            ))}
          </View>
        </View>

        {/* CAMPUS */}
        <View style={S.section}>
          <Text style={[S.sectionTitle, { color: colors.text }]}>{fr ? 'Nos campus' : 'Our campuses'}</Text>
          {campus.map((c, i) => (
            <TouchableOpacity
              key={i}
              style={[S.expandCard, { backgroundColor: colors.card, borderColor: expandedCampus === i ? RED : colors.border }]}
              onPress={() => setExpandedCampus(expandedCampus === i ? null : i)}
              activeOpacity={0.8}>
              <View style={S.expandHeader}>
                <View style={[S.expandIcon, { backgroundColor: 'rgba(196,58,47,0.11)' }]}>
                  <Feather name={c.icon} size={17} color={colors.redInk} />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={[S.expandNom, { color: colors.text }]}>{c.nom}</Text>
                  <View style={S.villeRow}>
                    <Feather name="map-pin" size={10} color={colors.muted} />
                    <Text style={[S.villeText, { color: colors.muted }]}>{c.ville}</Text>
                  </View>
                </View>
                <Feather name={expandedCampus === i ? 'chevron-up' : 'chevron-down'} size={15} color={colors.muted} />
              </View>
              {expandedCampus === i && (
                <Text style={[S.expandDesc, { color: colors.muted, borderTopColor: colors.border }]}>{c.desc}</Text>
              )}
            </TouchableOpacity>
          ))}
        </View>

        {/* ÉCOLES */}
        <View style={S.section}>
          <Text style={[S.sectionTitle, { color: colors.text }]}>{fr ? 'Nos écoles' : 'Our schools'}</Text>
          {ecoles.map((e, i) => (
            <TouchableOpacity
              key={i}
              style={[S.expandCard, { backgroundColor: colors.card, borderColor: expandedSchool === i ? e.color : colors.border }]}
              onPress={() => setExpandedSchool(expandedSchool === i ? null : i)}
              activeOpacity={0.8}>
              <View style={S.expandHeader}>
                <View style={[S.expandIcon, { backgroundColor: `${e.color}18` }]}>
                  <Feather name={e.icon} size={17} color={e.color} />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={[S.ecoleSigle, { color: e.color }]}>{e.sigle}</Text>
                  <Text style={[S.ecoleNom, { color: colors.text }]} numberOfLines={2}>{e.nom}</Text>
                  {e.annee && (
                    <Text style={[S.ecoleAnnee, { color: colors.muted }]}>
                      {fr ? `Depuis ${e.annee}` : `Since ${e.annee}`}
                    </Text>
                  )}
                </View>
                <Feather name={expandedSchool === i ? 'chevron-up' : 'chevron-down'} size={15} color={colors.muted} />
              </View>
              {expandedSchool === i && (
                <View style={[S.domainesWrapOuter, { borderTopColor: colors.border }]}>
                  <Text style={[S.domTitle, { color: colors.muted }]}>
                    {fr ? 'DOMAINES DE FORMATION' : 'FIELDS OF STUDY'}
                  </Text>
                  <View style={S.domainesWrap}>
                    {e.domaines.map((d, j) => (
                      <View key={j} style={[S.domaineBadge, { backgroundColor: `${e.color}12`, borderColor: `${e.color}30` }]}>
                        <Text style={[S.domaineBadgeText, { color: e.color }]}>{d}</Text>
                      </View>
                    ))}
                  </View>
                </View>
              )}
            </TouchableOpacity>
          ))}
        </View>

        {/* PARTENARIATS */}
        <View style={S.section}>
          <Text style={[S.sectionTitle, { color: colors.text }]}>
            {fr ? 'Partenariats internationaux' : 'International partnerships'}
          </Text>
          <Text style={[S.partenairesSub, { color: colors.muted }]}>
            {fr
              ? "L'IUC entretient des partenariats académiques permettant doubles diplômes, mobilité étudiante et cycles ingénieurs internationaux."
              : 'IUC maintains academic partnerships enabling double degrees, student mobility and international engineering programs.'}
          </Text>
          {partenaires.map((p, i) => (
            <View key={i} style={[S.partenaireCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
              <Text style={S.partenaireFlag}>{p.icon}</Text>
              <View style={{ flex: 1 }}>
                <Text style={[S.partenairePays, { color: colors.text }]}>{p.pays}</Text>
                <Text style={[S.partenaireDesc, { color: colors.muted }]}>{p.desc}</Text>
              </View>
            </View>
          ))}
        </View>

        {/* DEVENIR ÉTUDIANT */}
        <View style={S.section}>
          <View style={[S.devenirCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Image source={logoIcon} style={S.devenirLogo} resizeMode="contain" />
            <Text style={[S.devenirTitle, { color: colors.text }]}>
              {fr ? "Vous souhaitez rejoindre l'IUC ?" : 'Want to join IUC?'}
            </Text>
            <Text style={[S.devenirSub, { color: colors.muted }]}>
              {fr
                ? "L'IUC accueille chaque année des milliers d'étudiants dans ses 5 campus. Déposez votre candidature et rejoignez une institution d'excellence."
                : 'IUC welcomes thousands of students each year across its 5 campuses. Submit your application and join an institution of excellence.'}
            </Text>
            <TouchableOpacity style={[S.btnDevenirDisabled, { backgroundColor: colors.card2, borderColor: colors.border }]} disabled activeOpacity={1}>
              <Feather name="user-plus" size={15} color={colors.muted} />
              <Text style={[S.btnDevenirDisabledText, { color: colors.muted }]}>
                {fr ? "Devenir étudiant à l'IUC" : 'Become a student at IUC'}
              </Text>
            </TouchableOpacity>
            <Text style={[S.comingSoon, { color: colors.muted }]}>
              {fr ? '🔒 Fonctionnalité disponible prochainement' : '🔒 Feature coming soon'}
            </Text>
          </View>
        </View>

        {/* CTA CONNEXION */}
        <View style={{ paddingHorizontal: 22 }}>
          <TouchableOpacity onPress={() => navigation.goBack()} style={S.btnSignin} activeOpacity={0.85}>
            <Text style={S.btnSigninText}>
              {fr ? 'Je suis étudiant — Se connecter' : "I'm a student — Sign in"}
            </Text>
          </TouchableOpacity>
        </View>

        {/* CTA IUCBOT BAS */}
        <View style={{ paddingHorizontal: 22 }}>
          <TouchableOpacity
            onPress={() => navigation.navigate('Chat')}
            activeOpacity={0.85}
            style={[S.chatCtaBottom, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <View style={[S.expandIcon, { backgroundColor: 'rgba(196,58,47,0.11)' }]}>
              <Feather name="cpu" size={19} color={colors.redInk} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={[S.chatCtaTitle, { color: colors.text }]}>
                {fr ? 'Encore des questions ?' : 'Still have questions?'}
              </Text>
              <Text style={[S.chatCtaSub, { color: colors.muted }]}>
                {fr ? 'IUCBot est disponible 24h/24' : 'IUCBot is available 24/7'}
              </Text>
            </View>
            <Feather name="arrow-right" size={17} color={colors.redInk} />
          </TouchableOpacity>
        </View>

        <View style={{ height: 40 }} />
      </ScrollView>
    </View>
  );
}

const S = StyleSheet.create({
  root: { flex: 1 },
  scroll: { gap: 18 },
  topBar: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingHorizontal: 22, paddingTop: 56 },
  backBtn: { width: 38, height: 38, borderRadius: 13, alignItems: 'center', justifyContent: 'center', borderWidth: 1 },
  topTitle: { fontSize: 20, fontWeight: '800', letterSpacing: -0.4 },
  topSub: { fontSize: 11.5, marginTop: 1 },

  hero: { borderRadius: 22, padding: 22, gap: 10 },
  heroLogoWrap: { alignSelf: 'flex-start', backgroundColor: '#FFFFFF', borderRadius: 10, paddingHorizontal: 10, paddingVertical: 6 },
  heroLogo: { width: 140, height: 40 },
  heroTitle: { fontSize: 21, fontWeight: '800', lineHeight: 26, letterSpacing: -0.4 },
  heroSub: { fontSize: 12, lineHeight: 18 },
  heroPillsRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 4 },
  heroPill: { borderWidth: 1.5, borderRadius: 999, paddingHorizontal: 12, paddingVertical: 5 },
  heroPillText: { fontSize: 10.5, fontWeight: '800' },

  chatBanner: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 12,
    backgroundColor: '#C43A2F', borderRadius: 20, padding: 15,
    shadowColor: '#C43A2F', shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.35, shadowRadius: 18, elevation: 8,
  },
  chatBannerLeft: { flexDirection: 'row', alignItems: 'center', gap: 12, flex: 1 },
  chatBannerIcon: { width: 44, height: 44, borderRadius: 22, backgroundColor: 'rgba(255,255,255,0.16)', alignItems: 'center', justifyContent: 'center' },
  chatBannerTitle: { fontSize: 14, fontWeight: '800', color: '#fff' },
  chatBannerSub: { fontSize: 11, color: 'rgba(255,255,255,0.78)', marginTop: 2, lineHeight: 15 },
  chatBannerArrow: { width: 32, height: 32, borderRadius: 16, backgroundColor: 'rgba(255,255,255,0.16)', alignItems: 'center', justifyContent: 'center' },

  section: { paddingHorizontal: 22, gap: 10 },
  sectionTitle: { fontSize: 17, fontWeight: '800', letterSpacing: -0.3 },
  card: { borderRadius: 18, padding: 16, borderWidth: 1 },

  chiffresGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 9 },
  chiffreCard: { width: '30%', flexGrow: 1, borderRadius: 16, padding: 13, alignItems: 'center', borderWidth: 1, gap: 3 },
  chiffreVal: { fontSize: 21, fontWeight: '800' },
  chiffreLabel: { fontSize: 9.5, textAlign: 'center' },

  histoireRow: { flexDirection: 'row', gap: 12, alignItems: 'flex-start' },
  histoireIcon: { width: 30, height: 30, borderRadius: 9, alignItems: 'center', justifyContent: 'center', flexShrink: 0 },
  histoireLabel: { fontSize: 10, marginBottom: 2 },
  histoireVal: { fontSize: 12.5, fontWeight: '600', lineHeight: 18 },
  divider: { height: 1, marginTop: 13 },

  timelineTitle: { fontSize: 13.5, fontWeight: '800', marginBottom: 14 },
  timelineItem: { flexDirection: 'row', gap: 12 },
  timelineLeft: { alignItems: 'center', width: 18 },
  timelineDot: { width: 11, height: 11, borderRadius: 6 },
  timelineLine: { width: 2, flex: 1, minHeight: 22, marginVertical: 4, borderRadius: 1 },
  timelineContent: { flex: 1, paddingBottom: 18 },
  timelineAnnee: { fontSize: 12, fontWeight: '800' },
  timelineEcole: { fontSize: 13, fontWeight: '700', marginTop: 1 },
  timelineDesc: { fontSize: 11, marginTop: 2, lineHeight: 16 },

  expandCard: { borderRadius: 16, borderWidth: 1.5, overflow: 'hidden' },
  expandHeader: { flexDirection: 'row', alignItems: 'center', gap: 12, padding: 14 },
  expandIcon: { width: 38, height: 38, borderRadius: 12, alignItems: 'center', justifyContent: 'center', flexShrink: 0 },
  expandNom: { fontSize: 13, fontWeight: '700' },
  villeRow: { flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 2 },
  villeText: { fontSize: 10.5 },
  expandDesc: { fontSize: 12, lineHeight: 18, paddingHorizontal: 14, paddingVertical: 11, borderTopWidth: 1 },

  ecoleSigle: { fontSize: 12, fontWeight: '800', letterSpacing: 0.5 },
  ecoleNom: { fontSize: 12, fontWeight: '600', lineHeight: 17, marginTop: 1 },
  ecoleAnnee: { fontSize: 10, marginTop: 3 },
  domainesWrapOuter: { padding: 14, borderTopWidth: 1, gap: 9 },
  domTitle: { fontSize: 9.5, fontWeight: '700', letterSpacing: 0.8 },
  domainesWrap: { flexDirection: 'row', flexWrap: 'wrap', gap: 6 },
  domaineBadge: { paddingHorizontal: 9, paddingVertical: 4, borderRadius: 999, borderWidth: 1 },
  domaineBadgeText: { fontSize: 10.5, fontWeight: '600' },

  partenairesSub: { fontSize: 12, lineHeight: 18 },
  partenaireCard: { borderRadius: 16, padding: 14, borderWidth: 1, flexDirection: 'row', alignItems: 'center', gap: 13 },
  partenaireFlag: { fontSize: 26 },
  partenairePays: { fontSize: 13.5, fontWeight: '700' },
  partenaireDesc: { fontSize: 11, marginTop: 2 },

  devenirCard: { borderRadius: 20, padding: 22, alignItems: 'center', gap: 12, borderWidth: 1 },
  devenirLogo: { width: 72, height: 72, marginBottom: 2 },
  devenirTitle: { fontSize: 16.5, fontWeight: '800', textAlign: 'center' },
  devenirSub: { fontSize: 12, textAlign: 'center', lineHeight: 18 },
  btnDevenirDisabled: { flexDirection: 'row', alignItems: 'center', gap: 8, borderWidth: 1, borderRadius: 14, padding: 14, width: '100%', justifyContent: 'center', opacity: 0.7 },
  btnDevenirDisabledText: { fontSize: 13.5, fontWeight: '600' },
  comingSoon: { fontSize: 11, textAlign: 'center' },

  btnSignin: {
    backgroundColor: '#C43A2F', borderRadius: 16, padding: 16, alignItems: 'center',
    shadowColor: '#C43A2F', shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.35, shadowRadius: 16, elevation: 7,
  },
  btnSigninText: { color: '#fff', fontSize: 14.5, fontWeight: '800' },

  chatCtaBottom: { flexDirection: 'row', alignItems: 'center', gap: 13, borderRadius: 18, padding: 15, borderWidth: 1 },
  chatCtaTitle: { fontSize: 13.5, fontWeight: '700' },
  chatCtaSub: { fontSize: 11, marginTop: 2 },
});
