import React, { useState } from 'react';
import {
  View, Text, TextInput, TouchableOpacity,
  StyleSheet, ActivityIndicator, Alert,
  KeyboardAvoidingView, Platform, Image, ScrollView
} from 'react-native';
import { Feather } from '@expo/vector-icons';
import { useAuth } from '../../context/AuthContext';
import { useSettings } from '../../context/SettingsContext';
import api from '../../services/api';

// v2 — Login : logo blanc arrondi, pills Étudiant/Visiteur, carte arrondie 26
// avec note verte, inputs sur fond input, bouton rouge ombré.
// Logique conservée : check-matricule → champ mot de passe conditionnel.

export default function LoginScreen({ navigation }) {
  const { login } = useAuth();
  const { colors, t, langue } = useSettings();
  const fr = langue === 'fr';
  const [matricule, setMatricule]                 = useState('');
  const [password, setPassword]                   = useState('');
  const [hasPassword, setHasPassword]             = useState(false);
  const [checkDone, setCheckDone]                 = useState(false);
  const [checkingMatricule, setCheckingMatricule] = useState(false);
  const [loading, setLoading]                     = useState(false);
  const [showPassword, setShowPassword]           = useState(false);

  const checkMatricule = async (mat) => {
    const value = (mat || matricule).trim();
    if (!value) return;
    setCheckingMatricule(true);
    try {
      const res = await api.post('/etudiant/check-matricule', { matricule: value });
      setHasPassword(res.data.has_password === true);
      setCheckDone(true);
    } catch (e) {
      setHasPassword(false);
      setCheckDone(true);
    } finally {
      setCheckingMatricule(false);
    }
  };

  const handleLogin = async () => {
    if (!matricule.trim()) {
      Alert.alert('Erreur', fr ? 'Matricule requis.' : 'Student ID required.');
      return;
    }
    if (!checkDone) {
      setLoading(true);
      try {
        const res = await api.post('/etudiant/check-matricule', { matricule: matricule.trim() });
        const needsPassword = res.data.has_password === true;
        setHasPassword(needsPassword);
        setCheckDone(true);
        if (needsPassword && !password) { setLoading(false); return; }
      } catch (e) {
        setHasPassword(false);
        setCheckDone(true);
      }
    }
    if (hasPassword && !password) {
      Alert.alert('Erreur', fr ? 'Mot de passe requis.' : 'Password required.');
      setLoading(false);
      return;
    }
    setLoading(true);
    try {
      await login(matricule.trim(), password);
    } catch (e) {
      Alert.alert('Erreur', e?.response?.data?.message || e?.message || 'Connexion impossible.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={[S.root, { backgroundColor: colors.bg }]}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
      <ScrollView contentContainerStyle={S.scroll} showsVerticalScrollIndicator={false}>

        {/* LOGO + TITRE */}
        <View style={S.titleWrap}>
          <Image
            source={require('../../../assets/images/logo-icon.png')}
            style={S.logoImg}
            resizeMode="contain"
          />
          <Text style={[S.appName, { color: colors.text }]}>IUCTrack</Text>
          <Text style={[S.appSub, { color: colors.muted }]}>Smart Administration & Tracking System</Text>
        </View>

        {/* PILLS ÉTUDIANT / VISITEUR */}
        <View style={S.tabsRow}>
          <View style={S.tabActive}>
            <Text style={S.tabActiveText}>{fr ? 'Étudiant' : 'Student'}</Text>
          </View>
          <TouchableOpacity
            style={[S.tabInactive, { backgroundColor: colors.card, borderColor: colors.border }]}
            onPress={() => navigation.navigate('DecouvrirIUC')}>
            <Text style={[S.tabInactiveText, { color: colors.muted }]}>{fr ? 'Visiteur' : 'Visitor'}</Text>
          </TouchableOpacity>
        </View>

        {/* CARTE FORMULAIRE */}
        <View style={[S.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Text style={[S.cardTitle, { color: colors.text }]}>{t.connexion}</Text>

          {!hasPassword && (
            <View style={S.hintRow}>
              <View style={S.hintDot} />
              <Text style={[S.hintText, { color: colors.greenInk }]}>
                {fr
                  ? 'Première connexion ? Entrez uniquement votre matricule. Vous pourrez définir un mot de passe depuis votre profil.'
                  : 'First login? Enter your student ID only. You can set a password from your profile.'}
              </Text>
            </View>
          )}

          <Text style={[S.label, { color: colors.muted }]}>{t.matricule}</Text>
          <TextInput
            style={[S.input, { backgroundColor: colors.input, color: colors.text, borderColor: colors.border }]}
            placeholder="IUC2024-0042"
            placeholderTextColor={colors.muted}
            value={matricule}
            onChangeText={(text) => {
              setMatricule(text);
              setHasPassword(false);
              setCheckDone(false);
              setPassword('');
            }}
            onBlur={() => checkMatricule(matricule)}
            onSubmitEditing={() => checkMatricule(matricule)}
            autoCapitalize="characters"
            returnKeyType="next"
          />

          {checkingMatricule && (
            <ActivityIndicator size="small" color="#C43A2F" style={{ marginTop: -4, marginBottom: 2 }} />
          )}

          {hasPassword && (
            <>
              <Text style={[S.label, { color: colors.muted }]}>
                {fr ? 'Mot de passe' : 'Password'}
              </Text>
              <View style={S.inputRow}>
                <TextInput
                  style={[S.input, { flex: 1, marginBottom: 0, backgroundColor: colors.input, color: colors.text, borderColor: colors.border }]}
                  placeholder="••••••••"
                  placeholderTextColor={colors.muted}
                  value={password}
                  onChangeText={setPassword}
                  secureTextEntry={!showPassword}
                  returnKeyType="done"
                  onSubmitEditing={handleLogin}
                  autoFocus
                />
                <TouchableOpacity
                  onPress={() => setShowPassword(!showPassword)}
                  style={[S.eyeBtn, { backgroundColor: colors.input, borderColor: colors.border }]}>
                  <Feather name={showPassword ? 'eye-off' : 'eye'} size={18} color={colors.muted} />
                </TouchableOpacity>
              </View>
            </>
          )}

          <TouchableOpacity
            style={S.btnLogin}
            onPress={handleLogin}
            disabled={loading || checkingMatricule}
            activeOpacity={0.85}>
            {loading || checkingMatricule
              ? <ActivityIndicator color="#fff" />
              : <Text style={S.btnLoginText}>{t.seconnecter}</Text>}
          </TouchableOpacity>
        </View>

        {/* VISITEUR */}
        <TouchableOpacity
          style={[S.btnVisitor, { backgroundColor: colors.card, borderColor: colors.border }]}
          onPress={() => navigation.navigate('DecouvrirIUC')}>
          <Feather name="home" size={14} color={colors.muted} />
          <Text style={[S.btnVisitorText, { color: colors.muted }]}>{t.decouvrir}</Text>
        </TouchableOpacity>

        <Text style={[S.footer, { color: colors.muted }]}>
          {fr ? 'Problème ?  ' : 'Problem?  '}
          <Text style={[S.footerLink, { color: colors.greenInk }]}>
            {fr ? "Contacter l'administration" : 'Contact administration'}
          </Text>
        </Text>

      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const S = StyleSheet.create({
  root: { flex: 1 },
  scroll: { flexGrow: 1, justifyContent: 'center', padding: 24, gap: 16 },
  titleWrap: { alignItems: 'center', gap: 9, marginBottom: 6 },
  logoImg: { width: 76, height: 76, borderRadius: 20, backgroundColor: '#FFFFFF' },
  appName: { fontSize: 30, fontWeight: '800', letterSpacing: -0.5 },
  appSub: { fontSize: 11, textAlign: 'center' },
  tabsRow: { flexDirection: 'row', gap: 9, justifyContent: 'center' },
  tabActive: { backgroundColor: '#C43A2F', paddingHorizontal: 20, paddingVertical: 9, borderRadius: 999 },
  tabActiveText: { color: '#fff', fontSize: 13, fontWeight: '700' },
  tabInactive: { paddingHorizontal: 20, paddingVertical: 9, borderRadius: 999, borderWidth: 1 },
  tabInactiveText: { fontSize: 13, fontWeight: '600' },
  card: { borderRadius: 26, padding: 22, gap: 11, borderWidth: 1 },
  cardTitle: { fontSize: 19, fontWeight: '800' },
  hintRow: { flexDirection: 'row', alignItems: 'flex-start', gap: 8 },
  hintDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: '#22A06B', marginTop: 5, flexShrink: 0 },
  hintText: { fontSize: 11.5, flex: 1, lineHeight: 17 },
  label: { fontSize: 11.5, fontWeight: '600' },
  input: { borderRadius: 14, padding: 15, fontSize: 14.5, borderWidth: 1 },
  inputRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  eyeBtn: { borderRadius: 14, padding: 15, borderWidth: 1 },
  btnLogin: {
    backgroundColor: '#C43A2F', borderRadius: 15, padding: 16, alignItems: 'center', marginTop: 4,
    shadowColor: '#C43A2F', shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.35, shadowRadius: 16, elevation: 7,
  },
  btnLoginText: { color: '#fff', fontSize: 15, fontWeight: '700' },
  btnVisitor: { borderRadius: 15, padding: 14, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, borderWidth: 1 },
  btnVisitorText: { fontSize: 13, fontWeight: '600' },
  footer: { textAlign: 'center', fontSize: 11 },
  footerLink: { fontWeight: '600' },
});
